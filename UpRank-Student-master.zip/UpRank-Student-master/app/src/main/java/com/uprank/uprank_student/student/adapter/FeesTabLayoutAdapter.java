package com.uprank.uprank_student.student.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.uprank.uprank_student.student.fragments.PaymentHistory;
import com.uprank.uprank_student.student.fragments.PaymentReciept;


public class FeesTabLayoutAdapter extends FragmentPagerAdapter {


    private int totalTabs;
    private Context myContext;


    public FeesTabLayoutAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm, totalTabs);

        this.myContext = context;
        this.totalTabs = totalTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:

                PaymentHistory paymentHistory = new PaymentHistory();
                return paymentHistory;

            case 1:

                PaymentReciept paymentReciept = new PaymentReciept();
                return paymentReciept;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return totalTabs;
    }
}
