package com.uprank.uprank_student.student.fragments;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.manojbhadane.QButton;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Fees;
import com.uprank.uprank_student.student.model.FeesResponse;
import com.uprank.uprank_student.student.model.Installment;
import com.uprank.uprank_student.student.model.InstallmentResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utilities.Colors;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;
import java.util.Arrays;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class PaymentHistory extends Fragment implements View.OnClickListener {

    private PieChart chart;
    private ApiInterface apiInterface;
    private Student student;
    private Pref pref = new Pref();
    private int installments_no, paid_installments_count;
    private Double pending_fees, total_fees, paid_fees;
    private Fees fees;
    private ArrayList<Installment> installmentArrayList;
    private ArrayList<String> installments;
    private ArrayList<String> dueDates;
    private TextView textView_total_paid, textView_total_due, textView_last_paid, textView_last_paid_date, textView_due_amount, textView_due_date;
    ArrayList<PieEntry> values = new ArrayList<>();
    private QButton button_pay_now;

    public PaymentHistory() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_payment_history, container, false);

        student = pref.getStudentDataPref(getActivity());
        apiInterface = ApiClient.getClient(getActivity()).create(ApiInterface.class);

        initView(view);

        return view;
    }

    private void initView(View view) {


        chart = view.findViewById(R.id.piechart);
        chart.setBackgroundColor(Color.WHITE);

        moveOffScreen();

        chart.setUsePercentValues(true);
        chart.getDescription().setEnabled(false);

        chart.setCenterTextTypeface(Typeface.DEFAULT);
        //chart.setCenterText(generateCenterSpannableText());

        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.WHITE);

        chart.setTransparentCircleColor(Color.WHITE);
        chart.setTransparentCircleAlpha(110);

        chart.setHoleRadius(58f);
        chart.setTransparentCircleRadius(61f);

        chart.setDrawCenterText(true);

        chart.setRotationEnabled(false);
        chart.setHighlightPerTapEnabled(true);

        chart.setMaxAngle(180f); // HALF CHART
        chart.setRotationAngle(180f);
        chart.setCenterTextOffset(0, -20);


        chart.animateY(1400, Easing.EaseInOutQuad);

        Legend l = chart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setDrawInside(false);
        l.setXEntrySpace(7f);
        l.setYEntrySpace(0f);
        l.setYOffset(0f);

        // entry label styling
        chart.setEntryLabelColor(Color.WHITE);
        chart.setEntryLabelTypeface(Typeface.DEFAULT);
        chart.setEntryLabelTextSize(12f);

        textView_total_paid = view.findViewById(R.id.text_total_paid);
        textView_total_due = view.findViewById(R.id.text_total_due);
        textView_last_paid = view.findViewById(R.id.text_last_paid);
        textView_last_paid_date = view.findViewById(R.id.text_last_paid_date);
        textView_due_amount = view.findViewById(R.id.text_due_amount);
        textView_due_date = view.findViewById(R.id.text_due_date);
        button_pay_now = view.findViewById(R.id.button_pay_now);
        button_pay_now.setOnClickListener(this);

        getFeesDetails();

    }

    private void setData(int count, float range) {


        String[] val = {"Paid", "Due"};

        values.add(new PieEntry(Float.parseFloat(String.valueOf(paid_fees)), val[0]));
        values.add(new PieEntry(Float.parseFloat(String.valueOf(pending_fees)), val[1]));


        PieDataSet dataSet = new PieDataSet(values, "");
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);

        dataSet.setColors(Colors.MATERIAL_COLORS);
        //dataSet.setSelectionShift(0f);

        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.WHITE);
        data.setValueTypeface(Typeface.DEFAULT);
        chart.setData(data);

        chart.invalidate();
    }

    private void moveOffScreen() {

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        int height = displayMetrics.heightPixels;

        int offset = (int) (height * 0.1); /* percent to move */
        LinearLayout.LayoutParams rlParams =
                (LinearLayout.LayoutParams) chart.getLayoutParams();
        rlParams.setMargins(0, 0, 0, -offset);
        chart.setLayoutParams(rlParams);
    }

    private SpannableString generateCenterSpannableText() {

        SpannableString s = new SpannableString("MPAndroidChart\ndeveloped by Philipp Jahoda");
        s.setSpan(new RelativeSizeSpan(1.7f), 0, 14, 0);
        s.setSpan(new StyleSpan(Typeface.NORMAL), 14, s.length() - 15, 0);
        s.setSpan(new ForegroundColorSpan(Color.GRAY), 14, s.length() - 15, 0);
        s.setSpan(new RelativeSizeSpan(.8f), 14, s.length() - 15, 0);
        s.setSpan(new StyleSpan(Typeface.ITALIC), s.length() - 14, s.length(), 0);
        s.setSpan(new ForegroundColorSpan(ColorTemplate.getHoloBlue()), s.length() - 14, s.length(), 0);
        return s;
    }

    private void getFeesDetails() {

        apiInterface.get_student_fees(Integer.parseInt(student.getInstituteId()), student.getCourse(), student.getBatch()).enqueue(new Callback<FeesResponse>() {
            @Override
            public void onResponse(Call<FeesResponse> call, Response<FeesResponse> response) {


                if (response.body().getCode().equals("200")) {

                    fees = response.body().getFees().get(0);
                    installments_no = Integer.parseInt(fees.getInstallnemtCount());
                    total_fees = Double.valueOf(fees.getTotalFees());

                    String intall = fees.getAmount();

                    if (intall.contains(",")) {

                        String[] install_values = intall.split(",");
                        installments = new ArrayList<String>(Arrays.asList(install_values));
                    } else {

                        installments.add(fees.getAmount());

                    }

                    String due_date = fees.getDueDate();

                    if (due_date.contains(",")) {

                        String[] due_date_values = due_date.split(",");
                        dueDates = new ArrayList<String>(Arrays.asList(due_date_values));
                    } else {

                        dueDates.add(fees.getDueDate());

                    }

                    getInstallments();

                } else {

                    CommonUtils.errorToast(getActivity(), "No Fees Available");
                }
            }

            @Override
            public void onFailure(Call<FeesResponse> call, Throwable t) {

            }
        });

    }

    private void getInstallments() {

        paid_fees = 0.0;

        apiInterface.get_student_fees_installments(student.getId()).enqueue(new Callback<InstallmentResponse>() {
            @Override
            public void onResponse(Call<InstallmentResponse> call, Response<InstallmentResponse> response) {


                if (response.body().getCode().equals("200")) {

                    installmentArrayList = (ArrayList<Installment>) response.body().getInstallments();

                    paid_installments_count = installmentArrayList.size();

                    for (Installment installment : installmentArrayList) {

                        paid_fees = paid_fees + Double.parseDouble(installment.getInstallments());
                    }

                    textView_total_paid.setText(paid_fees + "");

                    if (paid_fees == total_fees) {

                        pending_fees = 0.0;
                    } else {

                        pending_fees = total_fees - paid_fees;
                        button_pay_now.setVisibility(View.VISIBLE);
                    }

                    textView_total_due.setText(pending_fees + "");
                    textView_last_paid.setText(installmentArrayList.get(0).getInstallments());
                    textView_last_paid_date.setText(installmentArrayList.get(0).getCreatedDate());
                    textView_due_amount.setText(installments.get(installments.size() - 1));
                    textView_due_date.setText(dueDates.get(dueDates.size() - 1));

                    setData(2, 100);


                } else {

                    CommonUtils.errorToast(getActivity(), "No Fees Paid");
                }
            }

            @Override
            public void onFailure(Call<InstallmentResponse> call, Throwable t) {

            }
        });

    }

    @Override
    public void onClick(View v) {

    }
}
