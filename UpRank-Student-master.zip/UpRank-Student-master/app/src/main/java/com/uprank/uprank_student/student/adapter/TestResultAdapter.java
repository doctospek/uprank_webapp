package com.uprank.uprank_student.student.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.TestResult;

import java.util.List;

public class TestResultAdapter extends BaseAdapter {

    private Context context;
    private List<TestResult> testResultList;

    public TestResultAdapter(Context context, List<TestResult> testResultList) {
        this.context = context;
        this.testResultList = testResultList;
    }

    @Override
    public int getCount() {
        return testResultList.size();
    }

    @Override
    public Object getItem(int position) {
        return testResultList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = layoutInflater.inflate(R.layout.testresult_view, parent, false);

        TextView textView_name = convertView.findViewById(R.id.text_test_name);
        TextView textView_subject = convertView.findViewById(R.id.text_test_subject);
        TextView textView_obtained = convertView.findViewById(R.id.text_obtained_mark);
        TextView textView_total = convertView.findViewById(R.id.text_total_marks);
        TextView textView_correct = convertView.findViewById(R.id.text_correct_ans);
        TextView textView_incorrect = convertView.findViewById(R.id.text_incorrect_ans);
        TextView textView_total_ques = convertView.findViewById(R.id.text_total_questions);
        TextView textView_ob = convertView.findViewById(R.id.text_obtained);
        TextView textView_to = convertView.findViewById(R.id.text_total);

        TestResult testResult = testResultList.get(position);

        textView_name.setText(testResult.getTestName());
        textView_subject.setText(testResult.getSubjectName());

        String[] obtained = testResult.getResult().split("/");

        textView_obtained.setText(obtained[0]);
        //textView_ob.setText(obtained[0]);
        textView_total.setText("/ " + obtained[1]);
        //textView_to.setText(obtained[1]);

        String incorrect = String.valueOf(Integer.parseInt(obtained[1]) - Integer.parseInt(obtained[0]));

        textView_correct.setText(obtained[0]);
        textView_incorrect.setText(incorrect);
        textView_total_ques.setText("Total Questions : " + obtained[1]);


        return convertView;
    }
}
