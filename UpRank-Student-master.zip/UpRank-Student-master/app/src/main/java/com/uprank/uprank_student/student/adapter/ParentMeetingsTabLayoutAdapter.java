package com.uprank.uprank_student.student.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.uprank.uprank_student.student.fragments.PastExamFragment;
import com.uprank.uprank_student.student.fragments.PastParentMeetingsFragment;
import com.uprank.uprank_student.student.fragments.UpcomingExamFragment;
import com.uprank.uprank_student.student.fragments.UpcomingParentMeetingsFragment;


public class ParentMeetingsTabLayoutAdapter extends FragmentPagerAdapter {


    private int totalTabs;
    private Context myContext;


    public ParentMeetingsTabLayoutAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm, totalTabs);

        this.myContext = context;
        this.totalTabs = totalTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:

                UpcomingParentMeetingsFragment upcomingParentMeetingsFragment = new UpcomingParentMeetingsFragment();
                return upcomingParentMeetingsFragment;

            case 1:

                PastParentMeetingsFragment pastParentMeetingsFragment = new PastParentMeetingsFragment();
                return pastParentMeetingsFragment;

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return totalTabs;
    }
}
