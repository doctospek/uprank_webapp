
package com.uprank.uprank_student.student.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class InstituteResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("data")
    private List<Institute> mInstitute;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public List<Institute> getInstitute() {
        return mInstitute;
    }

    public void setInstitute(List<Institute> institute) {
        mInstitute = institute;
    }

}
