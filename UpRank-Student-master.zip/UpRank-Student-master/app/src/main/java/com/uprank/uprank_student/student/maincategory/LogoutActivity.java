package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.commonactivities.UserActivity;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.Pref;

public class LogoutActivity extends AppCompatActivity {

    Pref pref = new Pref();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);

        pref.clearSharedPref(LogoutActivity.this);
        startActivity(new Intent(getApplicationContext(), UserActivity.class));

    }
}