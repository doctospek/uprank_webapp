
package com.uprank.uprank_student.student.model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class TestResult {

    @SerializedName("created_on")
    private String mCreatedOn;
    @SerializedName("id")
    private String mId;
    @SerializedName("institute_id")
    private String mInstituteId;
    @SerializedName("remark")
    private String mRemark;
    @SerializedName("result")
    private String mResult;
    @SerializedName("student_id")
    private String mStudentId;
    @SerializedName("subject_name")
    private String mSubjectName;
    @SerializedName("test_id")
    private String mTestId;
    @SerializedName("test_name")
    private String mTestName;

    public String getCreatedOn() {
        return mCreatedOn;
    }

    public void setCreatedOn(String createdOn) {
        mCreatedOn = createdOn;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstituteId() {
        return mInstituteId;
    }

    public void setInstituteId(String instituteId) {
        mInstituteId = instituteId;
    }

    public String getRemark() {
        return mRemark;
    }

    public void setRemark(String remark) {
        mRemark = remark;
    }

    public String getResult() {
        return mResult;
    }

    public void setResult(String result) {
        mResult = result;
    }

    public String getStudentId() {
        return mStudentId;
    }

    public void setStudentId(String studentId) {
        mStudentId = studentId;
    }

    public String getSubjectName() {
        return mSubjectName;
    }

    public void setSubjectName(String subjectName) {
        mSubjectName = subjectName;
    }

    public String getTestId() {
        return mTestId;
    }

    public void setTestId(String testId) {
        mTestId = testId;
    }

    public String getTestName() {
        return mTestName;
    }

    public void setTestName(String testName) {
        mTestName = testName;
    }

}
