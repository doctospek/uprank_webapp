package com.uprank.uprank_student.student.adapter;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.uprank.uprank_student.student.fragments.ProgressFragment;
import com.uprank.uprank_student.student.fragments.ReportcardFragment;


public class ReportCardTabLayoutAdapter extends FragmentPagerAdapter {


    private int totalTabs;
    private Context myContext;


    public ReportCardTabLayoutAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm, totalTabs);

        this.myContext = context;
        this.totalTabs = totalTabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:

                return new ReportcardFragment();

            case 1:

                return new ProgressFragment();

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return totalTabs;
    }
}
