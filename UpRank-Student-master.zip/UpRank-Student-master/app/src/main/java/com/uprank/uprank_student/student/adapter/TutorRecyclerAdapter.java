package com.uprank.uprank_student.student.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.uprank.uprank_student.R;

public class TutorRecyclerAdapter extends RecyclerView.Adapter<TutorRecyclerAdapter.ViewHolder> {

    private Context context;
    private ItemListener mListener;

    public TutorRecyclerAdapter(Context context, ItemListener itemListener) {
        this.context = context;
        mListener = itemListener;
    }

    @NonNull
    @Override
    public TutorRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.course_recyclerview, parent, false);
        return new TutorRecyclerAdapter.ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull TutorRecyclerAdapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 3;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    class ViewHolder extends RecyclerView.ViewHolder {


        ViewHolder(View itemView) {
            super(itemView);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    mListener.onItemClick(v);
                }
            });

        }
    }

    public interface ItemListener {
        void onItemClick(View view);
    }
}
