
package com.uprank.uprank_student.student.model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class TestResultResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("msg")
    private String mMsg;
    @SerializedName("testResult")
    private List<TestResult> mTestResult;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public String getMsg() {
        return mMsg;
    }

    public void setMsg(String msg) {
        mMsg = msg;
    }

    public List<TestResult> getTestResult() {
        return mTestResult;
    }

    public void setTestResult(List<TestResult> testResult) {
        mTestResult = testResult;
    }

}
