
package com.uprank.uprank_student.student.model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Student {

    @SerializedName("admission_date")
    private String mAdmissionDate;
    @SerializedName("age")
    private String mAge;
    @SerializedName("batch")
    private String mBatch;
    @SerializedName("course")
    private String mCourse;
    @SerializedName("current_address")
    private String mCurrentAddress;
    @SerializedName("dob")
    private String mDob;
    @SerializedName("email")
    private String mEmail;
    @SerializedName("end_date")
    private String mEndDate;
    @SerializedName("fname")
    private String mFname;
    @SerializedName("gender")
    private String mGender;
    @SerializedName("guardian_email")
    private String mGuardianEmail;
    @SerializedName("guardian_mobile")
    private String mGuardianMobile;
    @SerializedName("highest_education")
    private String mHighestEducation;
    @SerializedName("id")
    private String mId;
    @SerializedName("institute_id")
    private String mInstituteId;
    @SerializedName("lname")
    private String mLname;
    @SerializedName("mname")
    private String mMname;
    @SerializedName("mobile")
    private String mMobile;
    @SerializedName("password")
    private String mPassword;
    @SerializedName("percentage")
    private String mPercentage;
    @SerializedName("permanent_address")
    private String mPermanentAddress;
    @SerializedName("result")
    private String mResult;
    @SerializedName("start_date")
    private String mStartDate;
    @SerializedName("total_fees")
    private String mTotalFees;
    @SerializedName("university")
    private String mUniversity;
    @SerializedName("year")
    private String mYear;
    @SerializedName("profile_pic")
    private String mProfilePic;
    @SerializedName("guardian_name")
    private String mGuardianName;

    @SerializedName("batch_name")
    private String mBatchName;
    @SerializedName("course_name")
    private String mCourseName;

    public String getAdmissionDate() {
        return mAdmissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        mAdmissionDate = admissionDate;
    }

    public String getAge() {
        return mAge;
    }

    public void setAge(String age) {
        mAge = age;
    }

    public String getBatch() {
        return mBatch;
    }

    public void setBatch(String batch) {
        mBatch = batch;
    }

    public String getCourse() {
        return mCourse;
    }

    public void setCourse(String course) {
        mCourse = course;
    }

    public String getCurrentAddress() {
        return mCurrentAddress;
    }

    public void setCurrentAddress(String currentAddress) {
        mCurrentAddress = currentAddress;
    }

    public String getDob() {
        return mDob;
    }

    public void setDob(String dob) {
        mDob = dob;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String email) {
        mEmail = email;
    }

    public String getEndDate() {
        return mEndDate;
    }

    public void setEndDate(String endDate) {
        mEndDate = endDate;
    }

    public String getFname() {
        return mFname;
    }

    public void setFname(String fname) {
        mFname = fname;
    }

    public String getGender() {
        return mGender;
    }

    public void setGender(String gender) {
        mGender = gender;
    }

    public String getGuardianEmail() {
        return mGuardianEmail;
    }

    public void setGuardianEmail(String guardianEmail) {
        mGuardianEmail = guardianEmail;
    }

    public String getGuardianMobile() {
        return mGuardianMobile;
    }

    public void setGuardianMobile(String guardianMobile) {
        mGuardianMobile = guardianMobile;
    }

    public String getHighestEducation() {
        return mHighestEducation;
    }

    public void setHighestEducation(String highestEducation) {
        mHighestEducation = highestEducation;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstituteId() {
        return mInstituteId;
    }

    public void setInstituteId(String instituteId) {
        mInstituteId = instituteId;
    }

    public String getLname() {
        return mLname;
    }

    public void setLname(String lname) {
        mLname = lname;
    }

    public String getMname() {
        return mMname;
    }

    public void setMname(String mname) {
        mMname = mname;
    }

    public String getMobile() {
        return mMobile;
    }

    public void setMobile(String mobile) {
        mMobile = mobile;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public String getPercentage() {
        return mPercentage;
    }

    public void setPercentage(String percentage) {
        mPercentage = percentage;
    }

    public String getPermanentAddress() {
        return mPermanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        mPermanentAddress = permanentAddress;
    }

    public String getResult() {
        return mResult;
    }

    public void setResult(String result) {
        mResult = result;
    }

    public String getStartDate() {
        return mStartDate;
    }

    public void setStartDate(String startDate) {
        mStartDate = startDate;
    }

    public String getTotalFees() {
        return mTotalFees;
    }

    public void setTotalFees(String totalFees) {
        mTotalFees = totalFees;
    }

    public String getUniversity() {
        return mUniversity;
    }

    public void setUniversity(String university) {
        mUniversity = university;
    }

    public String getYear() {
        return mYear;
    }

    public void setYear(String year) {
        mYear = year;
    }

    public String getmProfilePic() {
        return mProfilePic;
    }

    public void setmProfilePic(String mProfilePic) {
        this.mProfilePic = mProfilePic;
    }

    public String getmGuardianName() {
        return mGuardianName;
    }

    public void setmGuardianName(String mGuardianName) {
        this.mGuardianName = mGuardianName;
    }

    public String getmBatchName() {
        return mBatchName;
    }

    public void setmBatchName(String mBatchName) {
        this.mBatchName = mBatchName;
    }

    public String getmCourseName() {
        return mCourseName;
    }

    public void setmCourseName(String mCourseName) {
        this.mCourseName = mCourseName;
    }
}
