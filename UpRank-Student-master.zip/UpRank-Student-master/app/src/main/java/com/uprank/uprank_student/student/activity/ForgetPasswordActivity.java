package com.uprank.uprank_student.student.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.gson.JsonObject;
import com.mukesh.OtpView;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ForgetPasswordActivity extends AppCompatActivity implements View.OnClickListener {


    private EditText edtMobileNumber, edtNewPassword, edtConfirmNewPassword;

    OtpView edtVerifyOTP;

    private LinearLayout llGetOTP, llVerifyOtp, llChangePassword;

    private Button btnChangepassword, btnGetOTP, btnVerifyOtp;

    private String strUserVerifyOTP;
    private String strUserMobileNumber, strFirebaseOTP, user_id, strUserPassword;
    private String strUserReceivedOTP;

    FirebaseAuth mAuth;
    private Pref pref;
    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    ApiInterface apiInterface;
    private TextView txtResendOtp;
    Handler handler;
    private ProgressBar bar;
    TextView txt;
    Integer count = 1;
    private ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);

        initView();
    }

    private void initView() {

        pref = new Pref();
        apiInterface = ApiClient.getClient(ForgetPasswordActivity.this).create(ApiInterface.class);
        pd = new ProgressDialog(ForgetPasswordActivity.this);

        edtMobileNumber = findViewById(R.id.edt_MobileNo);
        edtVerifyOTP = findViewById(R.id.edt_recievedOTP);
        edtNewPassword = findViewById(R.id.edt_newpassFP);
        edtConfirmNewPassword = findViewById(R.id.edt_confirmnewpassFP);

        btnGetOTP = findViewById(R.id.btn_getotp);
        btnVerifyOtp = findViewById(R.id.btn_verifyotp);
        btnChangepassword = findViewById(R.id.btn_changePassword);

        llGetOTP = findViewById(R.id.layout_getOTP);
        llVerifyOtp = findViewById(R.id.layout_verifyOtp);
        llChangePassword = findViewById(R.id.layout_ChangePass);

        txtResendOtp = findViewById(R.id.txt_resendOTP);
        txt = findViewById(R.id.output);
        bar = (ProgressBar) findViewById(R.id.progressBar);

        addOnClickListener();

        StartFirebaseLogin();

        edtMobileNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {


            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                strUserMobileNumber = edtMobileNumber.getText().toString();

                if (strUserMobileNumber.length() != 10) {


                } else {

                    if (CommonUtils.isNetworkAvailable(ForgetPasswordActivity.this)) {

                        pd.show();
                        pd.setMessage("Verifying Mobile Number\nPlease wait...");

                        checkStudentExists();

                    } else {
                        CommonUtils.warningToast(ForgetPasswordActivity.this);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

    }

    private void addOnClickListener() {
        btnGetOTP.setOnClickListener(this);
        btnVerifyOtp.setOnClickListener(this);
        btnChangepassword.setOnClickListener(this);
        txtResendOtp.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        boolean isValidstrConfirmUserPasswod;
        boolean isValidstrUserPassword;
        boolean isValidstrBothPassword;
        switch (v.getId()) {

            case R.id.btn_getotp:

                strUserMobileNumber = edtMobileNumber.getText().toString();


                if (strUserMobileNumber.length() != 10) {
                    edtMobileNumber.setError("Enter Correct Mobile No.");

                } else {

                    pref.setForgatePassMoNo(getBaseContext(), strUserMobileNumber);

                    showProgress();

                    sendVerificationCode("+91" + strUserMobileNumber);
                    llGetOTP.setVisibility(View.GONE);
                    llVerifyOtp.setVisibility(View.VISIBLE);
                }

                break;

            case R.id.btn_verifyotp:


                break;

            case R.id.btn_changePassword:

                strUserPassword = edtNewPassword.getText().toString();
                String strConfirmUserPassword = edtConfirmNewPassword.getText().toString();
                if (!strUserPassword.isEmpty()) {
                    isValidstrUserPassword = true;
                } else {
                    edtNewPassword.setError("Enter New Password");
                    isValidstrUserPassword = false;
                }

                if (!strConfirmUserPassword.isEmpty()) {
                    isValidstrConfirmUserPasswod = true;
                } else {
                    edtNewPassword.setError("Enter Confirm Password");
                    isValidstrConfirmUserPasswod = false;
                }

                if (strUserPassword.equals(strConfirmUserPassword)) {
                    isValidstrBothPassword = true;
                } else {
                    isValidstrBothPassword = false;
                    edtConfirmNewPassword.setError("Password Not Matching");
                }
                if (isValidstrBothPassword && isValidstrUserPassword && isValidstrConfirmUserPasswod) {
                    user_id = pref.getBasicLoginUserId(ForgetPasswordActivity.this);

                    updatePassword();
                    //callUpdatePasswordService(UID, strUserPassword);
                } else {
                    Toast.makeText(ForgetPasswordActivity.this, "Invalid Passwords", Toast.LENGTH_SHORT).show();
                }


                break;

            case R.id.txt_resendOTP:
                String PN = pref.getForgatePassMoNo(ForgetPasswordActivity.this);

                Log.e("PN", PN);

                if (PN.equals("MCA")) {

                } else {
                    String OTPA = pref.getBasicOTPattempt(ForgetPasswordActivity.this);
                    if (OTPA.equals("MCA")) {
                        pref.setBasicOTPattempt(ForgetPasswordActivity.this, "1");
                        txtResendOtp.setText("Didn't Receive the OTP? RESEND OTP\nRemaining attempts: " + "2");

                        sendVerificationCode("+91" + PN);
                        showProgress();


                    } else if (OTPA.equals("1")) {
                        pref.setBasicOTPattempt(ForgetPasswordActivity.this, "2");
                        txtResendOtp.setText("Didn't Receive the OTP? RESEND OTP\nRemaining attempts: " + "1");

                        sendVerificationCode("+91" + PN);
                        showProgress();


                    } else if (OTPA.equals("2")) {
                        pref.setBasicOTPattempt(ForgetPasswordActivity.this, "3");
                        txtResendOtp.setText("Didn't Receive the OTP? RESEND OTP\nTry After Some Time ");
                        sendVerificationCode("+91" + PN);
                        showProgress();


                    } else {
                        txtResendOtp.setText("Didn't Receive the OTP? RESEND OTP\nTry After Some Time ");
                        Toast.makeText(ForgetPasswordActivity.this, "Try After Some Time", Toast.LENGTH_SHORT).show();
                    }

                }
                break;

        }
    }

    private void StartFirebaseLogin() {
        mAuth = FirebaseAuth.getInstance();
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(ForgetPasswordActivity.this, "verification completed", Toast.LENGTH_SHORT).show();

                String code = phoneAuthCredential.getSmsCode();

                if (code != null) {
                    edtVerifyOTP.setItemCount(code.length());
                    edtVerifyOTP.setText(code);
                    bar.setVisibility(View.GONE);
                    txtResendOtp.setVisibility(View.VISIBLE);
                    txt.setVisibility(View.INVISIBLE);
                    //verifying the code
                    verifyVerificationCode(code);
                }
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {

                Log.e("VerificationFailed", e.getMessage());
                Toast.makeText(ForgetPasswordActivity.this, "verification fialed", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s, forceResendingToken);
                strFirebaseOTP = s;
                Log.e("onsent", s);
                Toast.makeText(ForgetPasswordActivity.this, "Code sent", Toast.LENGTH_SHORT).show();
            }
        };
    }

    private void verifyVerificationCode(String code) {
        //creating the credential
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(strFirebaseOTP, code);
        //signing the Student
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //Call register service
                            bar.setVisibility(View.GONE);
                            llVerifyOtp.setVisibility(View.GONE);
                            llChangePassword.setVisibility(View.VISIBLE);
                            //Toast.makeText(ForgetPassword.this, "Verification Successful with OTP", Toast.LENGTH_SHORT).show();
                        } else {
                            if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                                // The verification code entered was invalid
                                edtVerifyOTP.setError("You entered Invalid OTP");
                            }
                        }
                    }
                });
    }

    private void sendVerificationCode(String phoneNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                60,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                ForgetPasswordActivity.this,               // Activity (for callback binding)
                mCallbacks);        // OnVerificationStateChangedCallbacks
        //  Toast.makeText(ForgetPasswordActivity.this, "PhoneAuthProvider called " + phoneNumber, Toast.LENGTH_SHORT).show();
    }


    private void checkStudentExists() {

        apiInterface.check_student_exists(strUserMobileNumber).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.body().toString());
                    String code = jsonObject.getString("code");
                    if (code.equals("200")) {

                        pd.dismiss();
                        btnGetOTP.setVisibility(View.VISIBLE);
                        pref.setBasicLoginUserId(ForgetPasswordActivity.this, jsonObject.getString("id"));

                    } else {

                        pd.dismiss();
                        btnGetOTP.setVisibility(View.GONE);
                        CommonUtils.errorToast(ForgetPasswordActivity.this, "Mobile Number Doesn't Exists.");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    pd.dismiss();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

                pd.dismiss();
            }
        });

    }

    public void showProgress() {
        count = 30;
        txtResendOtp.setVisibility(View.INVISIBLE);
        txt.setVisibility(View.VISIBLE);
        bar.setMax(30);
        bar.setVisibility(View.VISIBLE);
        bar.setProgress(0);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                bar.setVisibility(View.GONE);
                txt.setVisibility(View.GONE);
                txtResendOtp.setVisibility(View.VISIBLE);
            }
        }, 30000);

        new CountDownTimer(30000, 1000) {

            @Override
            public void onTick(long l) {
                txt.setText(String.valueOf(count) + ":00 sec");
                count--;
            }

            @Override
            public void onFinish() {

            }
        }.start();

    }

    private void updatePassword() {

        apiInterface.update_password(user_id, strUserPassword).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.body().toString());
                    String code = jsonObject.getString("code");
                    if (code.equals("200")) {

                        CommonUtils.successToast(ForgetPasswordActivity.this, "Password Updated Successfully");
                        startActivity(new Intent(ForgetPasswordActivity.this, StudentLoginActivity.class));

                    } else {

                        CommonUtils.errorToast(ForgetPasswordActivity.this, "Password Not Updated Successfully");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });

    }

}
