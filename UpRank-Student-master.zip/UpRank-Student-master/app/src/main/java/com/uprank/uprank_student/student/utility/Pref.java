package com.uprank.uprank_student.student.utility;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.uprank.uprank_student.student.model.Institute;
import com.uprank.uprank_student.student.model.Student;


public class Pref {

    private String SHARED_PREF_NAME = "UTS";

    public void setStudentDataPref(Context context, Student Student) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(Student);
        prefsEditor.putString("StudentData", json);
        prefsEditor.apply();
    }

    public Student getStudentDataPref(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("StudentData", "");
        return gson.fromJson(json, Student.class);
    }

    public void setInstitutePref(Context context, Institute institute) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(institute);
        prefsEditor.putString("InstituteData", json);
        prefsEditor.apply();
    }

    public Institute getInstitutePref(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("InstituteData", "");
        return gson.fromJson(json, Institute.class);
    }

    public String getBasicLoginFirebaseAccessToken(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        return sharedPreferences.getString("token", "");
    }

    public void setBasicLoginFirebaseAccessToken(Context context, String token) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("token", token);
        editor.apply();
    }

    public void setForgatePassMoNo(Context context, String string) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = sharedPreferences.edit();
        prefsEditor.putString("mobileno", string);
        prefsEditor.apply();
    }

    public String getForgatePassMoNo(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);

        return sharedPreferences.getString("mobileno", "");
    }

    public void setBasicOTPattempt(Context context, String attempt) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("attempt", attempt);
        editor.commit();
    }

    public String getBasicOTPattempt(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        return sharedPreferences.getString("attempt", SHARED_PREF_NAME);
    }

    public void setBasicLoginUserId(Context context, String UserId) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("UserId", UserId);
        editor.commit();
    }

    public String getBasicLoginUserId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(SHARED_PREF_NAME, 0);
        return sharedPreferences.getString("UserId", SHARED_PREF_NAME);
    }

    public void clearSharedPref(Context context) {

        SharedPreferences preferences = context.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

    }

}
