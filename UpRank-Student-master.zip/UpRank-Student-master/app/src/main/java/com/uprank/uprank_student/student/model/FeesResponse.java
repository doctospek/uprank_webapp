
package com.uprank.uprank_student.student.model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class FeesResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("fees")
    private List<Fees> mFees;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public List<Fees> getFees() {
        return mFees;
    }

    public void setFees(List<Fees> fees) {
        mFees = fees;
    }

}
