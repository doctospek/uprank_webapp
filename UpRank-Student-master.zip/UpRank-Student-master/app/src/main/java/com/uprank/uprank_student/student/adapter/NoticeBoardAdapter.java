package com.uprank.uprank_student.student.adapter;

import android.content.Context;
import android.graphics.Color;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import com.devs.readmoreoption.ReadMoreOption;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Notice;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;
import java.util.Random;

public class NoticeBoardAdapter extends BaseAdapter {


    private ReadMoreOption readMoreOption;
    private Context context;
    private ArrayList<Notice> noticeArrayList = new ArrayList<>();
    ApiInterface apiInterface;
    String[] color_array = {"#D1C4E9", "#C5CAE9", "#E1BEE7", "#F8BBD0", "#C8E6C9", "#FFCCBC"};

    public NoticeBoardAdapter(Context context, ArrayList<Notice> noticeArrayList) {
        this.context = context;
        this.noticeArrayList = noticeArrayList;
        apiInterface = ApiClient.getClient(context).create(ApiInterface.class);
    }

    @Override
    public int getCount() {
        return noticeArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return noticeArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = layoutInflater.inflate(R.layout.noticeboard_view, parent, false);

        final Notice notice = noticeArrayList.get(position);

        TextView textView_title = convertView.findViewById(R.id.text_title);
        TextView textView_desc = convertView.findViewById(R.id.text_desc);
        CardView cardView = convertView.findViewById(R.id.cardview);


        readMoreOption = new ReadMoreOption.Builder(context).build();

        readMoreOption.addReadMoreTo(textView_desc, Html.fromHtml(notice.getNotice()));


        int rnd = new Random().nextInt(color_array.length);

        cardView.setCardBackgroundColor(Color.parseColor(color_array[rnd]));


        return convertView;
    }


}
