package com.uprank.uprank_student.student.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.DayAdapter;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.model.Timetable;
import com.uprank.uprank_student.student.model.TimetableResponse;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class DayFragment extends Fragment {

    private Student student;
    private Pref pref = new Pref();
    private ApiInterface apiInterface;
    private ListView listView;
    private ArrayList<Timetable> timetableArrayList;
    private String day;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_day, container, false);

        student = pref.getStudentDataPref(getActivity());
        apiInterface = ApiClient.getClient(getActivity()).create(ApiInterface.class);

        initView(view);

        return view;
    }

    private void initView(View view) {


        listView = view.findViewById(R.id.listview_timetable);

        day = getArguments().getString("day");

        getTimetable();


    }

    private void getTimetable() {

        apiInterface.student_timetable(Integer.parseInt(student.getInstituteId()), Integer.parseInt(student.getBatch()), Integer.parseInt(student.getCourse()), day).enqueue(new Callback<TimetableResponse>() {
            @Override
            public void onResponse(Call<TimetableResponse> call, Response<TimetableResponse> response) {

                if (response.body().getCode().equals("200")) {

                    //CommonUtils.successToast(getActivity(), response.body().getMsg());

                    timetableArrayList = (ArrayList<Timetable>) response.body().getTimetable();

                    DayAdapter dayAdapter = new DayAdapter(getActivity(), timetableArrayList);
                    listView.setAdapter(dayAdapter);

                } else {
                    //CommonUtils.errorToast(getActivity(), response.body().getMsg());
                }

            }

            @Override
            public void onFailure(Call<TimetableResponse> call, Throwable t) {

            }
        });


    }
}
