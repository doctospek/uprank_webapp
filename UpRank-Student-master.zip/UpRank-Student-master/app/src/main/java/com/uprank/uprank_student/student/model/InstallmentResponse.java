
package com.uprank.uprank_student.student.model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class InstallmentResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("installments")
    private List<Installment> mInstallments;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public List<Installment> getInstallments() {
        return mInstallments;
    }

    public void setInstallments(List<Installment> installments) {
        mInstallments = installments;
    }

}
