package com.uprank.uprank_student.student.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.manojbhadane.QButton;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.maincategory.ExitActivity;
import com.uprank.uprank_student.student.model.Institute;
import com.uprank.uprank_student.student.model.InstituteResponse;
import com.uprank.uprank_student.student.model.LoginResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StudentLoginActivity extends AppCompatActivity implements View.OnClickListener {

    private QButton qButton;
    EditText editText_mobile, editText_password;
    ApiInterface apiInterface;
    String str_mobile, str_password;
    Student student;
    Pref pref = new Pref();
    Institute institute;
    TextView textView_forget_Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_login);

        apiInterface = ApiClient.getClient(StudentLoginActivity.this).create(ApiInterface.class);

        initView();
    }

    private void initView() {

        editText_password = findViewById(R.id.edit_password);
        editText_mobile = findViewById(R.id.edit_mobile);
        qButton = findViewById(R.id.button_login);
        textView_forget_Password = findViewById(R.id.text_forget_password);

        qButton.setOnClickListener(this);
        textView_forget_Password.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.button_login:

                str_mobile = editText_mobile.getText().toString();
                str_password = editText_password.getText().toString();

                if (CommonUtils.isNetworkAvailable(StudentLoginActivity.this)) {

                    Login();

                } else {
                    CommonUtils.warningToast(StudentLoginActivity.this);
                }


                break;

            case R.id.text_forget_password:

                startActivity(new Intent(StudentLoginActivity.this, ForgetPasswordActivity.class));
                break;
        }
    }

    private void Login() {

        apiInterface.login(str_mobile, str_password).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                if (response.body().getCode().equals("200")) {


                    student = response.body().getStudent().get(0);
                    pref.setStudentDataPref(StudentLoginActivity.this, student);

                    getInstitute();

                } else {


                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

            }
        });
    }

    private void getInstitute() {

        apiInterface.get_student_institute(Integer.parseInt(student.getInstituteId())).enqueue(new Callback<InstituteResponse>() {
            @Override
            public void onResponse(Call<InstituteResponse> call, Response<InstituteResponse> response) {

                if (response.body().getCode().equals("200")) {
                    CommonUtils.successToast(StudentLoginActivity.this, "Login Successful !");


                    institute = response.body().getInstitute().get(0);
                    pref.setInstitutePref(StudentLoginActivity.this, institute);

                    startActivity(new Intent(StudentLoginActivity.this, StudentDashboard.class));


                } else {

                    CommonUtils.errorToast(StudentLoginActivity.this, "Login Failed !");


                }
            }

            @Override
            public void onFailure(Call<InstituteResponse> call, Throwable t) {

            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(StudentLoginActivity.this, ExitActivity.class);

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);

        startActivity(intent);
    }
}
