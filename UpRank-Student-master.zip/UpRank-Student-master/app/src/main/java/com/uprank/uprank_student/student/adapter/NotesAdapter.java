package com.uprank.uprank_student.student.adapter;

import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.shockwave.pdfium.PdfDocument;
import com.shockwave.pdfium.PdfiumCore;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Note;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.io.File;
import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.ViewHolder> {

    private Context context;
    private List<Note> noteArrayList;
    private ApiInterface apiInterface;
    Pref pref = new Pref();
    private static final String URL = "http://saiinfra.co.in/drline.saiinfra.co.in/uprank/app_api/teacher_api/uploads/";
    ProgressDialog progressDialog;

    public NotesAdapter(Context context, List<Note> noteArrayList) {
        this.context = context;
        this.noteArrayList = noteArrayList;

        apiInterface = ApiClient.getClient(context).create(ApiInterface.class);


    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.notes_view, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Note note = noteArrayList.get(position);

        holder.textView_chapter.setText(note.getChapter());
        holder.textView_teacher.setText("By : " + note.getmStaffName());
        holder.textView_created.setText(note.getCreatedAt().substring(0, 11));
        holder.textView_file_name.setText(note.getFileName());

        holder.imageView_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Download().execute(URL + note.getFileName(), note.getFileName());
            }
        });

        if (note.getFileTag().equals("pdf")) {

            holder.imageView_file.setImageBitmap(generateImageFromPdf(URL + note.getFileName()));

        } else {
            Glide.with(context)
                    .load(URL + note.getFileName())
                    .placeholder(R.mipmap.notes)
                    .into(holder.imageView_file);
        }

    }

    @Override
    public int getItemCount() {
        return noteArrayList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imageView_file, imageView_download;
        TextView textView_chapter, textView_file_name, textView_created, textView_teacher, textView_course;

        ViewHolder(View itemView) {
            super(itemView);
            this.imageView_file = (ImageView) itemView.findViewById(R.id.image_file);
            this.imageView_download = (ImageView) itemView.findViewById(R.id.image_download);
            this.textView_chapter = (TextView) itemView.findViewById(R.id.text_chapter_name);
            this.textView_file_name = (TextView) itemView.findViewById(R.id.text_file_name);
            this.textView_created = (TextView) itemView.findViewById(R.id.text_created_date);
            this.textView_teacher = (TextView) itemView.findViewById(R.id.text_teacher_name);

            ;

        }

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private class Download extends AsyncTask<String, Void, Void> {

        File direct = null;
        String fileName = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog = new ProgressDialog(context);
            progressDialog.setTitle("Downloading");
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
        }

        @Override
        protected Void doInBackground(String... strings) {
            String fileUrl = strings[0];   // -> http://maven.apache.org/maven-1.x/maven.pdf
            fileName = strings[1];  // -> maven.pdf

            direct =
                    new File(Environment
                            .getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                            .getAbsolutePath() + "/" + "UpRank" + "/");


            if (!direct.exists()) {
                direct.mkdir();
                Log.d("DOWNLOADIMAGE", "dir created for first time");
            }

            DownloadManager dm = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
            Uri downloadUri = Uri.parse(fileUrl);
            DownloadManager.Request request = new DownloadManager.Request(downloadUri);
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                    .setAllowedOverRoaming(false)
                    .setTitle(fileName)
                    .setMimeType("*/*")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                            File.separator + "UpRank" + File.separator + fileName);

            dm.enqueue(request);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            progressDialog.dismiss();
            super.onPostExecute(aVoid);

            try {
                if (direct != null) {

                    final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                    alertDialogBuilder.setTitle("Download");
                    alertDialogBuilder.setMessage("Notes Downloaded Successfully");
                    alertDialogBuilder.setCancelable(false);
                    alertDialogBuilder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                            dialog.dismiss();
                        }
                    });

                    alertDialogBuilder.show();

                } else {

                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {

                        }
                    }, 3000);

                    Log.e("Download Failed", "Download Failed");

                    CommonUtils.errorToast(context, "Download Failed");

                }
            } catch (Exception e) {
                e.printStackTrace();

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                    }
                }, 3000);
                Log.e("Download Failed", "Download Failed with Exception - " + e.getLocalizedMessage());

                CommonUtils.errorToast(context, "Download Failed");

            }

        }
    }

    private Bitmap generateImageFromPdf(String pdfUri) {
        int pageNumber = 0;
        Bitmap bmp = null;
        PdfiumCore pdfiumCore = new PdfiumCore(context);
        try {
            //http://www.programcreek.com/java-api-examples/index.php?api=android.os.ParcelFileDescriptor
            ParcelFileDescriptor fd = context.getContentResolver().openFileDescriptor(Uri.parse(pdfUri), "r");
            PdfDocument pdfDocument = pdfiumCore.newDocument(fd);
            pdfiumCore.openPage(pdfDocument, pageNumber);
            int width = pdfiumCore.getPageWidthPoint(pdfDocument, pageNumber);
            int height = pdfiumCore.getPageHeightPoint(pdfDocument, pageNumber);
            bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            pdfiumCore.renderPageBitmap(pdfDocument, bmp, pageNumber, 0, 0, width, height);
            //saveImage(bmp);

            pdfiumCore.closeDocument(pdfDocument); // important!

        } catch (Exception e) {
            //todo with exception
        }

        return bmp;
    }
}
