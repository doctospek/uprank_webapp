package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.HomeworkAdapter;
import com.uprank.uprank_student.student.model.Homework;
import com.uprank.uprank_student.student.model.HomeworkResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeWorkActivity extends AppCompatActivity implements View.OnClickListener {


    private ApiInterface apiInterface;
    private Pref pref = new Pref();
    private ArrayList<Homework> homeworkArrayList;
    private ListView listView;
    Student student;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_work);

        student = pref.getStudentDataPref(HomeWorkActivity.this);
        apiInterface = ApiClient.getClient(HomeWorkActivity.this).create(ApiInterface.class);

        initView();
    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        //toolbar.inflateMenu(R.menu.main_menu);

        listView = findViewById(R.id.list_homework);

        getHomework();


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {


        }
    }

/*    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_details:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }*/

    private void getHomework() {

        apiInterface.get_homework(Integer.parseInt(student.getBatch()), Integer.parseInt(student.getCourse()), Integer.parseInt(student.getInstituteId())).enqueue(new Callback<HomeworkResponse>() {
            @Override
            public void onResponse(Call<HomeworkResponse> call, Response<HomeworkResponse> response) {

                if (response.body().getCode().equals("200")) {

                    homeworkArrayList = (ArrayList<Homework>) response.body().getHomework();

                    HomeworkAdapter homeworkAdapter = new HomeworkAdapter(HomeWorkActivity.this, homeworkArrayList);
                    listView.setAdapter(homeworkAdapter);


                } else {

                }
            }

            @Override
            public void onFailure(Call<HomeworkResponse> call, Throwable t) {

            }
        });

    }
}
