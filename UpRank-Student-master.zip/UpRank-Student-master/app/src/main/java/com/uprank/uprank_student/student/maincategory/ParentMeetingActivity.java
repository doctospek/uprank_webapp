package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.ExamScheduleTabLayoutAdapter;
import com.uprank.uprank_student.student.adapter.ParentMeetingAdapter;
import com.uprank.uprank_student.student.adapter.ParentMeetingsTabLayoutAdapter;
import com.uprank.uprank_student.student.model.Meeting;
import com.uprank.uprank_student.student.model.MeetingResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ParentMeetingActivity extends AppCompatActivity {



    private static ViewPager tabPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parent_meeting);

        initView();

    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        tabLayout = findViewById(R.id.tabs);
        tabPager = findViewById(R.id.pagerTab);

        tabLayout.addTab(tabLayout.newTab().setText("Upcoming Meetings"));
        tabLayout.addTab(tabLayout.newTab().setText("Past Meetings"));
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#03DAC5"));
        tabLayout.setTabTextColors(Color.parseColor("#727272"), Color.parseColor("#03DAC5"));

        tabPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        ParentMeetingsTabLayoutAdapter parentMeetingsTabLayoutAdapter = new ParentMeetingsTabLayoutAdapter(getBaseContext(), getSupportFragmentManager(), tabLayout.getTabCount());
        tabPager.setAdapter(parentMeetingsTabLayoutAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tabPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

}
