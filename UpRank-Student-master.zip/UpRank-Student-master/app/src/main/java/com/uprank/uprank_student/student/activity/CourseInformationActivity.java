package com.uprank.uprank_student.student.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.devs.readmoreoption.ReadMoreOption;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.maincategory.TutorActivity;

public class CourseInformationActivity extends AppCompatActivity {

    private ReadMoreOption readMoreOption;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_information);

        textView=findViewById(R.id.text_description);

        readMoreOption = new ReadMoreOption.Builder(CourseInformationActivity.this).build();

        readMoreOption.addReadMoreTo(textView, Html.fromHtml(getString(R.string.lorem_ipsum)));

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), TutorActivity.class));
            }
        });
    }
}
