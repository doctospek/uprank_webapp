package com.uprank.uprank_student.student.maincategory;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.uprank.uprank_student.R;

public class ExitActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exit2);

        if(android.os.Build.VERSION.SDK_INT >= 21)
        {
            finishAndRemoveTask();
        }
        else
        {
            finish();
        }
    }
}