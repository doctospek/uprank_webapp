
package com.uprank.uprank_student.student.model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class MeetingResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("meeting")
    private List<Meeting> mMeeting;
    @SerializedName("msg")
    private String mMsg;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public List<Meeting> getMeeting() {
        return mMeeting;
    }

    public void setMeeting(List<Meeting> meeting) {
        mMeeting = meeting;
    }

    public String getMsg() {
        return mMsg;
    }

    public void setMsg(String msg) {
        mMsg = msg;
    }

}
