package com.uprank.uprank_student.student.webservices;

import com.google.gson.JsonObject;
import com.uprank.uprank_student.student.model.ExamResponse;
import com.uprank.uprank_student.student.model.FeesResponse;
import com.uprank.uprank_student.student.model.HomeworkResponse;
import com.uprank.uprank_student.student.model.InstallmentResponse;
import com.uprank.uprank_student.student.model.InstituteResponse;
import com.uprank.uprank_student.student.model.LoginResponse;
import com.uprank.uprank_student.student.model.MeetingResponse;
import com.uprank.uprank_student.student.model.NotesResponse;
import com.uprank.uprank_student.student.model.NoticeResponse;
import com.uprank.uprank_student.student.model.QuestionsResponse;
import com.uprank.uprank_student.student.model.TestResponse;
import com.uprank.uprank_student.student.model.TestResultResponse;
import com.uprank.uprank_student.student.model.TimetableResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {

    @GET("login.php")
    Call<LoginResponse> login(@Query("mobile") String mobile, @Query("password") String password);

    @GET("get_student_institute.php")
    Call<InstituteResponse> get_student_institute(@Query("id") int id);

    @GET("student_timetable.php")
    Call<TimetableResponse> student_timetable(@Query("institute_id") int institute_id, @Query("batch") int batch, @Query("course") int course, @Query("day") String day);

    @GET("get_homework.php")
    Call<HomeworkResponse> get_homework(@Query("batch") int batch, @Query("course") int course, @Query("institute_id") int institute_id);

    @GET("get_student_notice.php")
    Call<NoticeResponse> get_student_notice(@Query("institute_id") int institute_id);

    @GET("get_student_info.php")
    Call<LoginResponse> get_student_info(@Query("id") int id);

    @GET("check_student_exists.php")
    Call<JsonObject> check_student_exists(@Query("mobile") String mobile);

    @GET("update_password.php")
    Call<JsonObject> update_password(@Query("id") String id, @Query("newPassword") String newPassword);

    @GET("get_student_fees_installments.php")
    Call<InstallmentResponse> get_student_fees_installments(@Query("admission_id") String id);

    @GET("get_student_fees.php")
    Call<FeesResponse> get_student_fees(@Query("institute_id") int institute_id,
                                        @Query("course") String course,
                                        @Query("batch") String batch);

    @GET("add_payment_details.php")
    Call<FeesResponse> add_payment_details(@Query("admission_id") int admission_id,
                                           @Query("installments") String installments,
                                           @Query("payment_mode") String payment_mode,
                                           @Query("transaction_id") String transaction_id);

    @GET("get_test_series.php")
    Call<TestResponse> get_test_series(@Query("institute_id") int institute_id,
                                       @Query("course") String course,
                                       @Query("batch") String batch);

    @GET("get_test_questions.php")
    Call<QuestionsResponse> get_test_questions(@Query("serise_id") int institute_id);

    @GET("save_test_result.php")
    Call<JsonObject> save_test_result(@Query("student_id") int student_id,
                                      @Query("test_id") int test_id,
                                      @Query("institute_id") int institute_id,
                                      @Query("result") String result,
                                      @Query("remark") String remark);

    @GET("get_notes.php")
    Call<NotesResponse> get_notes(@Query("institute_id") int institute_id,
                                  @Query("course") String course,
                                  @Query("batch") String batch);

    @GET("get_parent_meeting.php")
    Call<MeetingResponse> get_parent_meeting(@Query("institute_id") int institute_id,
                                             @Query("course") String course,
                                             @Query("batch") String batch);

    @GET("get_upcoming_exam.php")
    Call<ExamResponse> get_upcoming_exams(@Query("institute_id") String institute_id,
                                          @Query("course") String course,
                                          @Query("batch") String batch);

    @GET("get_past_exam.php")
    Call<ExamResponse> get_past_exams(@Query("institute_id") String institute_id,
                                      @Query("course") String course,
                                      @Query("batch") String batch);

    @GET("get_test_result.php")
    Call<TestResultResponse> get_test_result(@Query("student_id") int student_id);

    @GET("update_student_profile.php")
    Call<LoginResponse> update_student_profile(@Query("id") String id,
                                               @Query("course") String course,
                                               @Query("batch") String batch,
                                               @Query("guardian_name") String guardian_name,
                                               @Query("guardian_mobile") String guardian_mobile,
                                               @Query("guardian_email") String guardian_email,
                                               @Query("current_address") String current_address,
                                               @Query("permanent_address") String permanent_address);

    @GET("check_given_test.php")
    Call<JsonObject> check_given_test(@Query("student_id") String id,
                                      @Query("test_id") String course,
                                      @Query("institute_id") String batch);
}
