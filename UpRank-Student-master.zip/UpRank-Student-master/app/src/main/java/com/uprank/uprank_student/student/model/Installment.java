
package com.uprank.uprank_student.student.model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Installment {

    @SerializedName("admission_id")
    private Object mAdmissionId;
    @SerializedName("bank_name")
    private String mBankName;
    @SerializedName("cheque_date")
    private String mChequeDate;
    @SerializedName("cheque_no")
    private String mChequeNo;
    @SerializedName("created_date")
    private String mCreatedDate;
    @SerializedName("id")
    private String mId;
    @SerializedName("installments")
    private String mInstallments;
    @SerializedName("mode")
    private String mMode;
    @SerializedName("payment_mode")
    private String mPaymentMode;
    @SerializedName("transaction_id")
    private String mTransactionId;

    public Object getAdmissionId() {
        return mAdmissionId;
    }

    public void setAdmissionId(Object admissionId) {
        mAdmissionId = admissionId;
    }

    public String getBankName() {
        return mBankName;
    }

    public void setBankName(String bankName) {
        mBankName = bankName;
    }

    public String getChequeDate() {
        return mChequeDate;
    }

    public void setChequeDate(String chequeDate) {
        mChequeDate = chequeDate;
    }

    public String getChequeNo() {
        return mChequeNo;
    }

    public void setChequeNo(String chequeNo) {
        mChequeNo = chequeNo;
    }

    public String getCreatedDate() {
        return mCreatedDate;
    }

    public void setCreatedDate(String createdDate) {
        mCreatedDate = createdDate;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstallments() {
        return mInstallments;
    }

    public void setInstallments(String installments) {
        mInstallments = installments;
    }

    public String getMode() {
        return mMode;
    }

    public void setMode(String mode) {
        mMode = mode;
    }

    public String getPaymentMode() {
        return mPaymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        mPaymentMode = paymentMode;
    }

    public String getTransactionId() {
        return mTransactionId;
    }

    public void setTransactionId(String transactionId) {
        mTransactionId = transactionId;
    }

}
