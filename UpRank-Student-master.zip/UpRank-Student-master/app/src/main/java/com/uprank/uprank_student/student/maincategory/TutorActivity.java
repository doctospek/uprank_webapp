package com.uprank.uprank_student.student.maincategory;


import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.CourseInformationActivity;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.TutorRecyclerAdapter;
import com.uprank.uprank_student.student.adapter.ViewPagerAdapter;
import com.uprank.uprank_student.student.model.Tag;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.imagepipeline.core.ImagePipelineConfig;
import com.yalantis.filter.adapter.FilterAdapter;
import com.yalantis.filter.listener.FilterListener;
import com.yalantis.filter.widget.Filter;
import com.yalantis.filter.widget.FilterItem;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class TutorActivity extends AppCompatActivity implements FilterListener<Tag>, TutorRecyclerAdapter.ItemListener {

    private int[] mColors;
    private String[] mTitles;
    private Filter<Tag> mFilter;
    TextView textView_seeAll;
    private static ViewPager mPager;
    ViewPagerAdapter viewPagerAdapter;
    RecyclerView recyclerView_new_course, recyclerView_trending_course;
    LinearLayout linearLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor);

        ImagePipelineConfig config = ImagePipelineConfig
                .newBuilder(this)
                .setDownsampleEnabled(true)
                .build();
        Fresco.initialize(this, config);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        mPager = (ViewPager) findViewById(R.id.pager);
        viewPagerAdapter = new ViewPagerAdapter(this, mPager);
        viewPagerAdapter.ScrollPager();

        //textView_seeAll = findViewById(R.id.text_see_all);

        mColors = getResources().getIntArray(R.array.colors);
        mTitles = getResources().getStringArray(R.array.job_titles);

       /* mFilter = (Filter<Tag>) findViewById(R.id.filter);
        mFilter.setAdapter(new Adapter(getTags()));
        mFilter.setListener(this);
        mFilter.expand();

        //the text to show when there's no selected items
        mFilter.setNoSelectedItemText("All Categories");
        mFilter.build();*/

        linearLayout = findViewById(R.id.linearLayout);
        final int N = mTitles.length; // total number of textviews to add

        final TextView[] myTextViews = new TextView[N]; // create an empty array;

        for (int i = 0; i < N; i++) {
            // create a new textview
            final TextView rowTextView = new TextView(this);

            // set some properties of rowTextView or something
            rowTextView.setText(mTitles[i]);
            rowTextView.setTextColor(Color.BLACK);
            rowTextView.setBackgroundResource(R.drawable.edt_text_border);
            rowTextView.setPadding(20, 20, 20, 20);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(10, 10, 10, 10);
            rowTextView.setLayoutParams(params);
            rowTextView.setTextSize(15f);

            // add the textview to the linearlayout
            linearLayout.addView(rowTextView);

            // save a reference to the textview for later
            myTextViews[i] = rowTextView;
        }

        recyclerView_new_course = findViewById(R.id.recyclerview_new_course);
        recyclerView_trending_course = findViewById(R.id.recyclerview_trending_course);

        TutorRecyclerAdapter tutorRecyclerAdapter = new TutorRecyclerAdapter(TutorActivity.this, this);
        recyclerView_new_course.setHasFixedSize(true);
        recyclerView_new_course.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        recyclerView_new_course.setAdapter(tutorRecyclerAdapter);

        recyclerView_trending_course.setHasFixedSize(true);
        recyclerView_trending_course.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        recyclerView_trending_course.setAdapter(tutorRecyclerAdapter);
    }

    private List<Tag> getTags() {
        List<Tag> tags = new ArrayList<>();

        for (int i = 0; i < mTitles.length; ++i) {
            tags.add(new Tag(mTitles[i], mColors[i]));
        }

        return tags;
    }

    @Override
    public void onFilterDeselected(Tag tag) {

    }

    @Override
    public void onFilterSelected(Tag tag) {

    }

    @Override
    public void onFiltersSelected(@NotNull ArrayList<Tag> arrayList) {

    }

    @Override
    public void onNothingSelected() {

    }

    @Override
    public void onItemClick(View view) {

        startActivity(new Intent(TutorActivity.this, CourseInformationActivity.class));
    }

    class Adapter extends FilterAdapter<Tag> {

        Adapter(@NotNull List<? extends Tag> items) {
            super(items);
        }

        @NotNull
        @Override
        public FilterItem createView(int position, Tag item) {
            FilterItem filterItem = new FilterItem(TutorActivity.this);

            filterItem.setStrokeColor(mColors[0]);
            filterItem.setTextColor(mColors[0]);
            filterItem.setCornerRadius(14);
            filterItem.setCheckedTextColor(ContextCompat.getColor(TutorActivity.this, android.R.color.white));
            filterItem.setColor(ContextCompat.getColor(TutorActivity.this, android.R.color.white));
            filterItem.setCheckedColor(mColors[position]);
            filterItem.setText(item.getText());
            filterItem.deselect();

            return filterItem;
        }
    }
}
