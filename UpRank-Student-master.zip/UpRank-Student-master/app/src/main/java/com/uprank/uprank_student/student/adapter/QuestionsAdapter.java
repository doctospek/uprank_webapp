package com.uprank.uprank_student.student.adapter;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.model.Question;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.model.Test;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class QuestionsAdapter extends RecyclerView.Adapter<QuestionsAdapter.ViewHolder> {


    private Context context;
    private List<Question> arrayList;
    private int totalMarks, correctAns;
    private Double totalPercentage;
    private String markedAns, obtinedMarks, remark;
    private ApiInterface apiInterface;
    private Student student;


    public QuestionsAdapter(Context context, List<Question> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
        apiInterface = ApiClient.getClient(context).create(ApiInterface.class);
        Pref pref = new Pref();
        student = pref.getStudentDataPref(context);
    }

    private static int getWidth(Context context) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        WindowManager windowmanager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        windowmanager.getDefaultDisplay().getMetrics(displayMetrics);
        return displayMetrics.widthPixels;
    }

    @NonNull
    @Override
    public QuestionsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.question_view, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(@NonNull final QuestionsAdapter.ViewHolder holder, int position) {

        final Question questions = arrayList.get(position);

        int ques_no = position + 1;

        totalMarks = arrayList.size();

        if (arrayList.size() - 1 == position) {
            holder.button.setVisibility(View.VISIBLE);
        } else {
            holder.button.setVisibility(View.GONE);
        }

        //Toast.makeText(context, "Ques no" + ques_no, Toast.LENGTH_SHORT).show();

        holder.textView.setText(questions.getQuestion());

        holder.radioButton_one.setText(questions.getAns1());
        holder.radioButton_two.setText(questions.getAns2());
        holder.radioButton_three.setText(questions.getAns3());
        holder.radioButton_four.setText(questions.getAns4());


        holder.textView_no.setText(ques_no + "/" + totalMarks);


        holder.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (checkedId) {

                    case R.id.radio_one:

                        clearBackground(holder.radioButton_three, holder.radioButton_two, holder.radioButton_four);
                        setBackground(holder.radioButton_one, "1", questions.getResult(), holder.textView);
                        countMark("1", questions.getResult());
                        disableRadioButton(holder.radioButton_two, holder.radioButton_three, holder.radioButton_four);

                        if ("1".equals(questions.getResult())) {

                        } else {

                            String ans = questions.getResult();

                            if (ans.equals("2")) {

                                holder.radioButton_two.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_two.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("3")) {

                                holder.radioButton_three.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_three.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("4")) {


                                holder.radioButton_four.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_four.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);
                            }

                        }

                        break;

                    case R.id.radio_two:

                        clearBackground(holder.radioButton_one, holder.radioButton_three, holder.radioButton_four);
                        setBackground(holder.radioButton_two, "2", questions.getResult(), holder.textView);
                        countMark("2", questions.getResult());
                        disableRadioButton(holder.radioButton_one, holder.radioButton_three, holder.radioButton_four);


                        if ("2".equals(questions.getResult())) {

                        } else {

                            String ans = questions.getResult();

                            if (ans.equals("1")) {

                                holder.radioButton_one.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_one.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("3")) {

                                holder.radioButton_three.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_three.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("4")) {


                                holder.radioButton_four.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_four.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);
                            }
                        }

                        break;

                    case R.id.radio_three:

                        clearBackground(holder.radioButton_one, holder.radioButton_two, holder.radioButton_four);
                        setBackground(holder.radioButton_three, "3", questions.getResult(), holder.textView);
                        countMark("3", questions.getResult());
                        disableRadioButton(holder.radioButton_two, holder.radioButton_one, holder.radioButton_four);

                        if ("3".equals(questions.getResult())) {

                        } else {

                            String ans = questions.getResult();

                            if (ans.equals("1")) {

                                holder.radioButton_one.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_one.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("2")) {

                                holder.radioButton_two.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_two.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("4")) {

                                holder.radioButton_four.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_four.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);
                            }
                        }

                        break;

                    case R.id.radio_four:

                        clearBackground(holder.radioButton_one, holder.radioButton_two, holder.radioButton_three);
                        setBackground(holder.radioButton_four, "4", questions.getResult(), holder.textView);
                        countMark("4", questions.getResult());
                        disableRadioButton(holder.radioButton_two, holder.radioButton_three, holder.radioButton_one);

                        if ("4".equals(questions.getResult())) {

                        } else {

                            String ans = questions.getResult();

                            if (ans.equals("1")) {

                                holder.radioButton_one.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_one.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("2")) {

                                holder.radioButton_two.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_two.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

                            } else if (ans.equals("3")) {


                                holder.radioButton_three.setBackgroundResource(R.color.LightGreen);
                                holder.radioButton_three.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);
                            }
                        }

                        break;

                    default:

                        break;
                }

            }
        });


        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                obtinedMarks = correctAns + "/" + totalMarks;

                totalPercentage = (Double.parseDouble(String.valueOf(correctAns)) / Double.parseDouble(String.valueOf(totalMarks))) * 100;

                Log.e("obtinedMarks", obtinedMarks);

                if (totalPercentage >= 50) {

                    remark = "Pass";

                } else {

                    remark = "Fail";
                }

                saveAnswers(questions);

            }
        });

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    private void countMark(String markedAns, String result) {

        if (markedAns.equals(result)) {

            correctAns++;
        }

    }


    private void openpdf(Uri path) {

        Intent pdfIntent = new Intent(Intent.ACTION_VIEW);
        pdfIntent.setDataAndType(path, "application/pdf");
        pdfIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Intent intentChooser = Intent.createChooser(pdfIntent, "Choose Pdf Application");
        try {
            context.startActivity(intentChooser);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "No Application available to view PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void setBackground(RadioButton radioButton, String marked_ans, String correct_ans, TextView textView) {


        if (correct_ans.equals(marked_ans)) {
            radioButton.setBackgroundResource(R.color.LightGreen);
            radioButton.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null);

            textView.setTextColor(Color.parseColor("#00FF00"));
            textView.setCompoundDrawablePadding(10);
            textView.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(context, R.drawable.ic_check_black_24dp), null, null, null);

        } else {
            radioButton.setBackgroundResource(R.color.LightPink);
            radioButton.setCompoundDrawablesWithIntrinsicBounds(null, null, ContextCompat.getDrawable(context, R.drawable.ic_clear_black_24dp), null);

            textView.setTextColor(Color.parseColor("#FF0000"));
            textView.setCompoundDrawablePadding(10);
            textView.setCompoundDrawablesWithIntrinsicBounds(ContextCompat.getDrawable(context, R.drawable.ic_clear_black_24dp), null, null, null);


        }


    }

    private void clearBackground(RadioButton radioButton1, RadioButton radioButton2, RadioButton radioButton3) {

        radioButton1.setBackgroundColor(0x00000000);
        radioButton2.setBackgroundColor(0x00000000);
        radioButton3.setBackgroundColor(0x00000000);
        radioButton1.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        radioButton2.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        radioButton3.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private void disableRadioButton(RadioButton radioButton1, RadioButton radioButton2, RadioButton radioButton3) {

        radioButton1.setEnabled(false);
        radioButton2.setEnabled(false);
        radioButton3.setEnabled(false);
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        TextView textView, textView_no;
        RadioGroup radioGroup;
        RadioButton radioButton_one, radioButton_two, radioButton_three, radioButton_four;
        Button button;


        ViewHolder(View itemView) {
            super(itemView);
            this.textView = (TextView) itemView.findViewById(R.id.text_questions);
            this.radioGroup = (RadioGroup) itemView.findViewById(R.id.radiogroup_ans);
            this.radioButton_one = (RadioButton) itemView.findViewById(R.id.radio_one);
            this.radioButton_two = (RadioButton) itemView.findViewById(R.id.radio_two);
            this.radioButton_three = (RadioButton) itemView.findViewById(R.id.radio_three);
            this.radioButton_four = (RadioButton) itemView.findViewById(R.id.radio_four);
            this.button = (Button) itemView.findViewById(R.id.button_submit_ans);
            this.textView_no = (TextView) itemView.findViewById(R.id.text_question_no);

        }
    }


    private void saveAnswers(Question question) {

        apiInterface.save_test_result(Integer.parseInt(student.getId()), Integer.parseInt(question.getSeriseId()), Integer.parseInt(student.getInstituteId()), obtinedMarks, remark).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.body().toString());

                    if (jsonObject.getString("code").equals("200")) {

                        CommonUtils.successToast(context, "Answers Submitted Successfully");

                        context.startActivity(new Intent(context, StudentDashboard.class));

                    } else {

                        CommonUtils.errorToast(context, "Answers Not Submitted Successfully");
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    CommonUtils.errorToast(context, "Something went wrong ! Answers Not Submitted Successfully");
                }

            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                CommonUtils.errorToast(context, "Something went wrong ! Answers Not Submitted Successfully");
            }
        });

    }

}
