
package com.uprank.uprank_student.student.model;

import com.google.gson.annotations.SerializedName;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Exam {

    @SerializedName("batch")
    private String mBatch;
    @SerializedName("batch_name")
    private String mBatchName;
    @SerializedName("chapter")
    private String mChapter;
    @SerializedName("course")
    private String mCourse;
    @SerializedName("course_name")
    private String mCourseName;
    @SerializedName("created_at")
    private String mCreatedAt;
    @SerializedName("exam_date")
    private String mExamDate;
    @SerializedName("exam_title")
    private String mExamTitle;
    @SerializedName("file_tag")
    private String mFileTag;
    @SerializedName("id")
    private String mId;
    @SerializedName("institute_id")
    private String mInstituteId;
    @SerializedName("quation_paper")
    private String mQuationPaper;
    @SerializedName("staff_id")
    private String mStaffId;
    @SerializedName("subject")
    private String mSubject;

    public String getBatch() {
        return mBatch;
    }

    public void setBatch(String batch) {
        mBatch = batch;
    }

    public String getBatchName() {
        return mBatchName;
    }

    public void setBatchName(String batchName) {
        mBatchName = batchName;
    }

    public String getChapter() {
        return mChapter;
    }

    public void setChapter(String chapter) {
        mChapter = chapter;
    }

    public String getCourse() {
        return mCourse;
    }

    public void setCourse(String course) {
        mCourse = course;
    }

    public String getCourseName() {
        return mCourseName;
    }

    public void setCourseName(String courseName) {
        mCourseName = courseName;
    }

    public String getCreatedAt() {
        return mCreatedAt;
    }

    public void setCreatedAt(String createdAt) {
        mCreatedAt = createdAt;
    }

    public String getExamDate() {
        return mExamDate;
    }

    public void setExamDate(String examDate) {
        mExamDate = examDate;
    }

    public String getExamTitle() {
        return mExamTitle;
    }

    public void setExamTitle(String examTitle) {
        mExamTitle = examTitle;
    }

    public String getFileTag() {
        return mFileTag;
    }

    public void setFileTag(String fileTag) {
        mFileTag = fileTag;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstituteId() {
        return mInstituteId;
    }

    public void setInstituteId(String instituteId) {
        mInstituteId = instituteId;
    }

    public String getQuationPaper() {
        return mQuationPaper;
    }

    public void setQuationPaper(String quationPaper) {
        mQuationPaper = quationPaper;
    }

    public String getStaffId() {
        return mStaffId;
    }

    public void setStaffId(String staffId) {
        mStaffId = staffId;
    }

    public String getSubject() {
        return mSubject;
    }

    public void setSubject(String subject) {
        mSubject = subject;
    }

}
