package com.uprank.uprank_student.student.activity;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.UploadProgressListener;
import com.bumptech.glide.Glide;
import com.iceteck.silicompressorr.SiliCompressor;
import com.manojbhadane.QButton;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.LoginResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditStudentProfileActivity extends AppCompatActivity implements View.OnClickListener {

    Student student;
    Pref pref = new Pref();
    ApiInterface apiInterface;
    EditText textView_name, textView_batch, textView_roll_no, textView_guardian_name, textView_guardian_contat, textView_present_address,
            textView_permanent_address, textView_guardian_email, textView_student_course;
    CircleImageView image, imageView_camera;
    String selectedFilename, mCurrentPhotoPath, student_name, student_course, student_batch, student_roll_no, student_guardian_name, guardian_contact, student_section, guardian_email, guardian_present_address, guardian_permanent_address;
    File file;
    private int GALLERY = 1, CAMERA = 2, STORAGE_PERMISSION_CODE = 123, WRITE_EXTERNAL_STORAGE = 12;
    String url = "http://saiinfra.co.in/drline.saiinfra.co.in/uprank/app_api/student_api/update_student_profile_image.php?apicall=uploadpic";
    QButton button_update;
    private Uri filePath;
    Bitmap bitmap;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student_profile);

        pd = new ProgressDialog(EditStudentProfileActivity.this);
        pd.setTitle("Image Uploading..Please Wait");
        pd.setCancelable(false);
        pd.setCanceledOnTouchOutside(false);

        checkPermission(Manifest.permission.CAMERA, CAMERA);
        checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);
        checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE);

        student = pref.getStudentDataPref(EditStudentProfileActivity.this);
        apiInterface = ApiClient.getClient(EditStudentProfileActivity.this).create(ApiInterface.class);

        initView();

    }


    private void initView() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });


        textView_name = findViewById(R.id.text_student_name);
        textView_batch = findViewById(R.id.student_batch);
        textView_roll_no = findViewById(R.id.student_roll_no);
        textView_guardian_name = findViewById(R.id.student_guardians_name);
        textView_guardian_contat = findViewById(R.id.student_guardian_contact);
        textView_present_address = findViewById(R.id.student_present_address);
        textView_permanent_address = findViewById(R.id.student_permanent_address);
        textView_student_course = findViewById(R.id.student_course);
        textView_guardian_email = findViewById(R.id.student_guardian_email);
        image = findViewById(R.id.image_profile_pic);
        imageView_camera = findViewById(R.id.edit_imageview);
        button_update = findViewById(R.id.button_update);


        textView_name.setText(student.getFname() + " " + student.getMname() + " " + student.getLname());
        textView_batch.setText(student.getmBatchName());
        textView_roll_no.setText(student.getId());
        textView_present_address.setText(student.getCurrentAddress());
        textView_permanent_address.setText(student.getPermanentAddress());
        textView_guardian_name.setText(student.getmGuardianName());
        textView_guardian_contat.setText(student.getGuardianMobile());
        textView_guardian_email.setText(student.getGuardianEmail());
        textView_student_course.setText(student.getmCourseName());
        Glide.with(EditStudentProfileActivity.this).load("http://saiinfra.co.in/drline.saiinfra.co.in/uprank/app_api/student_api/uploads/" + student.getmProfilePic()).error(R.mipmap.ic_launcher).into(image);

        //  getStudentInfo();

        imageView_camera.setOnClickListener(this::onClick);
        button_update.setOnClickListener(this::onClick);


    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {

            case R.id.edit_imageview:

                showFileChooser();

                break;

            case R.id.button_update:

                student_batch = textView_batch.getText().toString();
                student_course = textView_student_course.getText().toString();
                student_guardian_name = textView_guardian_name.getText().toString();
                guardian_contact = textView_guardian_contat.getText().toString();
                guardian_email = textView_guardian_email.getText().toString();
                guardian_present_address = textView_present_address.getText().toString();
                guardian_permanent_address = textView_permanent_address.getText().toString();

                updateStudent();

                break;
        }

    }

    private void showFileChooser() {


        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Photo Gallery",
                "Camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        /*Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);*/

        dispatchTakePictureIntent();
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        takePictureIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Ensure that there's a camera activity to handle the intent
            // Create the File where the photo should go
            File photoFile = null;
            try {
                photoFile = createImageFile();

            } catch (IOException ex) {
                // Error occurred while creating the File

                Toast.makeText(EditStudentProfileActivity.this, "exception" + ex.getMessage(), Toast.LENGTH_LONG).show();

                Log.e("Exception1", ex.getMessage());

            }
            // Continue only if the File was successfully created
            if (photoFile != null) {

                Uri photoURI = FileProvider.getUriForFile(this, "com.uprank.uprank_student.provider", photoFile);
                //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);

                startActivityForResult(takePictureIntent, CAMERA);
            } else {
                Toast.makeText(EditStudentProfileActivity.this, "exception: Photo file is null", Toast.LENGTH_LONG).show();

                Log.e("Exception2", "exception: Photo file is null");
            }
        }

    }

    private String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                + "0123456789"
                + "abcdefghijklmnopqrstuvxyz";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index
                    = (int) (AlphaNumericString.length()
                    * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString
                    .charAt(index));
        }

        return sb.toString();
    }

    private File createImageFile() throws IOException {

        String imageFileName = "Title_" + getAlphaNumericString(2);

        Log.e("IMAGENAME", imageFileName);

        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        Log.i("TAG", "photo path = " + mCurrentPhotoPath);
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {

                filePath = data.getData();
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), filePath);

                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(getBaseContext(), "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

            Uri tempUri = getImageUri(getApplicationContext(), bitmap);
            file = new File(getRealPathFromURI(tempUri));
            selectedFilename = file.getName();

            AndroidNetworking.upload(url)
                    .addMultipartFile("pic", file)
                    .addMultipartParameter("id", student.getId())
                    .addMultipartParameter("filename", selectedFilename)
                    .setTag("img")
                    .setPriority(Priority.HIGH)
                    .build()
                    .setUploadProgressListener(new UploadProgressListener() {
                        @Override
                        public void onProgress(long bytesUploaded, long totalBytes) {
                            // do anything with progress


                            pd.show();
                        }
                    })
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // do anything with response

                            pd.dismiss();

                            image.setImageURI(Uri.fromFile(file));

                            CommonUtils.showToast(EditStudentProfileActivity.this, "Image Uploaded successfully");

                            Log.e("ResponseImage", response.toString());
                        }

                        @Override
                        public void onError(ANError error) {
                            // handle error

                            pd.dismiss();

                            Log.e("UploadingError", error.getErrorBody());

                            CommonUtils.showToast(EditStudentProfileActivity.this, "Image Uploading Failed.\nPlease try Again..");

                        }
                    });

        } else if (requestCode == CAMERA) {

            file = new File(mCurrentPhotoPath);
            new ImageCompressionAsyncTask(this).execute(mCurrentPhotoPath,
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "");


        }
    }


    class ImageCompressionAsyncTask extends AsyncTask<String, Void, String> {

        Context mContext;

        ProgressDialog progressDialog;


        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog.show();
            progressDialog.setTitle("Uploading");
            progressDialog.setMessage("Image Uploading..Please Wait");
            progressDialog.setCancelable(false);
            progressDialog.setCanceledOnTouchOutside(false);
        }

        public ImageCompressionAsyncTask(Context context) {
            mContext = context;
            progressDialog = new ProgressDialog(EditStudentProfileActivity.this);
        }

        @Override
        protected String doInBackground(String... params) {

            String filePath = SiliCompressor.with(mContext).compress(params[0], new File(params[1]), true);
            return filePath;
        }

        @Override
        protected void onPostExecute(String s) {

            File imageFile = new File(s);

            selectedFilename = imageFile.getName();

            AndroidNetworking.upload(url)
                    .addMultipartFile("pic", imageFile)
                    .addMultipartParameter("id", student.getId())
                    .addMultipartParameter("filename", selectedFilename)
                    .setTag("img")
                    .setPriority(Priority.HIGH)
                    .build()
                    .setUploadProgressListener(new UploadProgressListener() {
                        @Override
                        public void onProgress(long bytesUploaded, long totalBytes) {
                            // do anything with progress
                        }
                    })
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // do anything with response

                            progressDialog.dismiss();

                            image.setImageURI(Uri.fromFile(imageFile));

                            CommonUtils.showToast(EditStudentProfileActivity.this, "Image Uploaded successfully");

                            Log.e("ResponseImage", response.toString());
                        }

                        @Override
                        public void onError(ANError error) {
                            // handle error

                            progressDialog.dismiss();

                            Log.e("UploadingError", error.toString());

                            CommonUtils.showToast(EditStudentProfileActivity.this, "Image Uploading Failed.\nPlease try Again..");

                        }
                    });


        }


    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title_" + getAlphaNumericString(2), null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getContentResolver() != null) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }

    public void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(EditStudentProfileActivity.this, permission)
                == PackageManager.PERMISSION_DENIED) {


            ActivityCompat.requestPermissions(EditStudentProfileActivity.this,
                    new String[]{permission},
                    requestCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == CAMERA) {

            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(EditStudentProfileActivity.this,
                        "Camera Permission Granted",
                        Toast.LENGTH_SHORT)
                        .show();
            } else {
                Toast.makeText(EditStudentProfileActivity.this,
                        "CAMERA Permission Denied",
                        Toast.LENGTH_SHORT)
                        .show();
            }
        }

    }

    private void updateStudent() {

        apiInterface.update_student_profile(student.getId(), student_course, student_batch, student_guardian_name, guardian_contact, guardian_email, guardian_present_address, guardian_permanent_address).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                if (response.body().getCode().equals("200")) {

                    student = response.body().getStudent().get(0);

                    pref.setStudentDataPref(EditStudentProfileActivity.this, student);

                    CommonUtils.successToast(EditStudentProfileActivity.this, "Student Information Updated Successfully");

                    startActivity(new Intent(EditStudentProfileActivity.this, StudentProfile.class));
                } else {
                    CommonUtils.errorToast(EditStudentProfileActivity.this, "Student Information not Updated Successfully..\nPlease Try Again !");
                }

            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

            }
        });


    }
}