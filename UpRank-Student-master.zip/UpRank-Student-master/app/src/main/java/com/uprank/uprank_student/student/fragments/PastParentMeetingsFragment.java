package com.uprank.uprank_student.student.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.ParentMeetingAdapter;
import com.uprank.uprank_student.student.model.Meeting;
import com.uprank.uprank_student.student.model.MeetingResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PastParentMeetingsFragment extends Fragment {

    private ApiInterface apiInterface;
    private Student student;
    private ParentMeetingAdapter parentMeetingAdapter;
    private Pref pref = new Pref();
    private ListView listView;
    private List<Meeting> meetingList;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        
        View view=inflater.inflate(R.layout.fragment_parent_meetings, container, false);

        apiInterface = ApiClient.getClient(getActivity()).create(ApiInterface.class);
        student = pref.getStudentDataPref(getActivity());

        initView(view);
        
        return view;
    }

    private void initView(View view) {

        listView = view.findViewById(R.id.list_meeting);

        getMeetings();

    }

    private void getMeetings() {


        apiInterface.get_parent_meeting(Integer.parseInt(student.getInstituteId()), student.getCourse(), student.getBatch()).enqueue(new Callback<MeetingResponse>() {
            @Override
            public void onResponse(Call<MeetingResponse> call, Response<MeetingResponse> response) {

                if (response.body().getCode().equals("200")) {

                    meetingList = response.body().getMeeting();

                    parentMeetingAdapter = new ParentMeetingAdapter(getActivity(), meetingList);
                    listView.setAdapter(parentMeetingAdapter);

                } else {

                    CommonUtils.errorToast(getActivity(), response.body().getMsg());
                }

            }

            @Override
            public void onFailure(Call<MeetingResponse> call, Throwable t) {

                CommonUtils.errorToast(getActivity(), "Something Went Wrong");
            }
        });
    }
}