package com.uprank.uprank_student.commonactivities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.activity.StudentLoginActivity;
import com.uprank.uprank_student.student.maincategory.ExitActivity;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.Pref;
import com.manojbhadane.QButton;

public class UserActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView imageView_parent, imageView_student;
    QButton button_continue;
    int click_id = 0;
    Pref pref = new Pref();
    Student student;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        student = pref.getStudentDataPref(UserActivity.this);
        initView();
        listeners();
    }

    private void initView() {

        imageView_parent = findViewById(R.id.image_parent);
        imageView_student = findViewById(R.id.image_student);
        button_continue = findViewById(R.id.button_continue);
    }

    private void listeners() {

        imageView_parent.setOnClickListener(this);
        imageView_student.setOnClickListener(this);
        button_continue.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.image_parent:

                imageView_parent.setBackgroundResource(R.drawable.color_circle);
                imageView_student.setBackgroundResource(R.drawable.circle);
                click_id = 2;

                break;
            case R.id.image_student:

                imageView_student.setBackgroundResource(R.drawable.color_circle);
                imageView_parent.setBackgroundResource(R.drawable.circle);
                click_id = 1;

                break;

            case R.id.button_continue:

                if (click_id == 1) {

                    if (student == null) {

                        startActivity(new Intent(getBaseContext(), StudentLoginActivity.class));
                    } else {

                        startActivity(new Intent(getBaseContext(), StudentDashboard.class));
                    }
                } else {

                }
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        Intent intent = new Intent(UserActivity.this, ExitActivity.class);

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);

        startActivity(intent);
    }
}
