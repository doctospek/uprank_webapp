
package com.uprank.uprank_student.student.model;

import java.util.List;
import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class TestResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("msg")
    private String mMsg;
    @SerializedName("test")
    private List<Test> mTest;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public String getMsg() {
        return mMsg;
    }

    public void setMsg(String msg) {
        mMsg = msg;
    }

    public List<Test> getTest() {
        return mTest;
    }

    public void setTest(List<Test> test) {
        mTest = test;
    }

}
