package com.uprank.uprank_student.student.maincategory;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;

public class LeaveActivity extends AppCompatActivity implements View.OnClickListener {

    Button button_submit_request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leave);

        initView();

    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        toolbar.inflateMenu(R.menu.main_menu);

        button_submit_request = findViewById(R.id.submit_request_button);
        button_submit_request.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_details:
                //startActivity(new Intent(LeaveActivity.this, LeaveDetailsActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.submit_request_button:

                showLeaveResponseDialog();
                break;


        }

    }

    private void showLeaveResponseDialog() {

        final Dialog dialog = new Dialog(LeaveActivity.this);
        dialog.setContentView(R.layout.leave_response_dialog);
        dialog.show();

        TextView textView = dialog.findViewById(R.id.text_cancel);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

    }
}
