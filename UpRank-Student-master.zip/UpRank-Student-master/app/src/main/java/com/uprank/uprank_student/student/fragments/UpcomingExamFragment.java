package com.uprank.uprank_student.student.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.ExamAdapter;
import com.uprank.uprank_student.student.model.Exam;
import com.uprank.uprank_student.student.model.ExamResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpcomingExamFragment extends Fragment implements View.OnClickListener {


    private ListView listView;
    private Student student;
    private Pref pref = new Pref();
    private ApiInterface apiInterface;
    private ExamAdapter examAdapter;
    private ArrayList<Exam> examArrayList;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_upcoming_exam, container, false);

        apiInterface = ApiClient.getClient(getActivity()).create(ApiInterface.class);
        student = pref.getStudentDataPref(getContext());

        initView(view);

        return view;
    }

    private void initView(View view) {

        listView = view.findViewById(R.id.listview_upcoming);

        getExams();

    }

    @Override
    public void onClick(View v) {

    }

    private void getExams() {

        apiInterface.get_upcoming_exams(student.getInstituteId(), student.getCourse(), student.getBatch()).enqueue(new Callback<ExamResponse>() {
            @Override
            public void onResponse(Call<ExamResponse> call, Response<ExamResponse> response) {

                if (response.body().getCode().equals("200")) {

                    examArrayList = (ArrayList<Exam>) response.body().getExam();
                    examAdapter = new ExamAdapter(getActivity(), examArrayList);
                    listView.setAdapter(examAdapter);

                } else {
                    CommonUtils.errorToast(getActivity(), response.body().getMsg());
                }
            }

            @Override
            public void onFailure(Call<ExamResponse> call, Throwable t) {

            }
        });
    }
}
