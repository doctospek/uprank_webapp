package com.uprank.uprank_student.student.adapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Slider;

import java.util.ArrayList;

public class ImageAdapter extends PagerAdapter {

    private ArrayList<Slider> IMAGES;
    private LayoutInflater inflater;
    private Context mContex;

    private int[] sliderImageId = new int[]{
            R.mipmap.attendance, R.mipmap.tutor, R.mipmap.schooltimetable, R.mipmap.fees, R.mipmap.noticeboard,
    };

    ImageAdapter(Context context, ArrayList<Slider> IMAGES) {

        this.mContex = context;
        this.IMAGES = IMAGES;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return IMAGES.size();
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view.equals(object);
    }


    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View imageLayout = inflater.inflate(R.layout.slidingimages_layout, view, false);

        assert imageLayout != null;
        final ImageView imageView = (ImageView) imageLayout
                .findViewById(R.id.image);

        final Slider slider = IMAGES.get(position);

        imageView.setImageResource(slider.getImg());

        //Picasso.with(mContex).load("http://saiinfra.co.in/socialjobs.saiinfra.co.in/images/" + slider.getImage()).into(imageView);

        view.addView(imageLayout, 0);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (slider.getUrl().length() == 0) {

                    Toast.makeText(mContex, "No Url", Toast.LENGTH_SHORT).show();

                } else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(slider.getUrl()));
                    mContex.startActivity(browserIntent);
                }


            }
        });

        return imageLayout;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);

    }
}
