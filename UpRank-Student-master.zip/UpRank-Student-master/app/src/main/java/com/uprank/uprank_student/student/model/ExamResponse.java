
package com.uprank.uprank_student.student.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import javax.annotation.Generated;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class ExamResponse {

    @SerializedName("code")
    private String mCode;
    @SerializedName("exam")
    private List<Exam> mExam;
    @SerializedName("msg")
    private String mMsg;

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public List<Exam> getExam() {
        return mExam;
    }

    public void setExam(List<Exam> exam) {
        mExam = exam;
    }

    public String getMsg() {
        return mMsg;
    }

    public void setMsg(String msg) {
        mMsg = msg;
    }

}
