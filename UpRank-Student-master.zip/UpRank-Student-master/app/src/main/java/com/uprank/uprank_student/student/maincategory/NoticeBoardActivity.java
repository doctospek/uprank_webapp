package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.NoticeBoardAdapter;
import com.uprank.uprank_student.student.model.Notice;
import com.uprank.uprank_student.student.model.NoticeResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NoticeBoardActivity extends AppCompatActivity implements View.OnClickListener {

    ListView listView;
    ApiInterface apiInterface;
    Pref pref = new Pref();
    Student student;
    ArrayList<Notice> noticeArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_board);

        student = pref.getStudentDataPref(NoticeBoardActivity.this);
        apiInterface = ApiClient.getClient(NoticeBoardActivity.this).create(ApiInterface.class);


        initView();
    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        //toolbar.inflateMenu(R.menu.main_menu);

        listView = findViewById(R.id.list_notice);

        getNotice();
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {


        }
    }


    private void getNotice() {

        apiInterface.get_student_notice(Integer.parseInt(student.getInstituteId())).enqueue(new Callback<NoticeResponse>() {
            @Override
            public void onResponse(Call<NoticeResponse> call, Response<NoticeResponse> response) {

                if (response.body().getCode().equals("200")) {

                    noticeArrayList = (ArrayList<Notice>) response.body().getNotice();

                    NoticeBoardAdapter noticeBoardAdapter = new NoticeBoardAdapter(NoticeBoardActivity.this, noticeArrayList);
                    listView.setAdapter(noticeBoardAdapter);

                } else {

                    CommonUtils.errorToast(NoticeBoardActivity.this, "No Notice Available");
                }


            }

            @Override
            public void onFailure(Call<NoticeResponse> call, Throwable t) {

            }
        });


    }
}
