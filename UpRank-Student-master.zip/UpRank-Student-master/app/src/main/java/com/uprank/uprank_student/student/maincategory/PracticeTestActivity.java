package com.uprank.uprank_student.student.maincategory;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.gson.JsonObject;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.TestAdapter;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.model.Test;
import com.uprank.uprank_student.student.model.TestResponse;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import org.json.JSONException;
import org.json.JSONObject;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PracticeTestActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView listView;
    private List<Test> arrayList = new ArrayList<>();
    private ApiInterface apiInterface;
    private Student student;
    private Pref pref = new Pref();
    private TestAdapter testAdapter;
    Test test;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practice_test);

        initView();


    }

    private void initView() {

        apiInterface = ApiClient.getClient(PracticeTestActivity.this).create(ApiInterface.class);
        student = pref.getStudentDataPref(PracticeTestActivity.this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });


        listView = findViewById(R.id.listview_test);
        listView.setOnItemClickListener(this);

        getPracticeTest();


    }

    private void getPracticeTest() {


        ProgressDialog progressDialog=new ProgressDialog(PracticeTestActivity.this);
        progressDialog.setTitle("Loading");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();


        apiInterface.get_test_series(Integer.parseInt(student.getInstituteId()), student.getCourse(), student.getBatch()).enqueue(new Callback<TestResponse>() {
            @Override
            public void onResponse(Call<TestResponse> call, Response<TestResponse> response) {

                if (response.body().getCode().equals("200")) {
                    progressDialog.dismiss();

                    arrayList = response.body().getTest();

                    testAdapter = new TestAdapter(PracticeTestActivity.this, arrayList);
                    listView.setAdapter(testAdapter);


                } else {

                    progressDialog.dismiss();
                    CommonUtils.errorToast(PracticeTestActivity.this, "No Test Series Found");
                }

            }

            @Override
            public void onFailure(Call<TestResponse> call, Throwable t) {
                progressDialog.dismiss();
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        test = (Test) testAdapter.getItem(position);

        check_test_given(test.getId());


    }

    private void check_test_given(String test_id) {

        apiInterface.check_given_test(student.getId(), test_id, student.getInstituteId()).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {

                try {
                    JSONObject jsonObject = new JSONObject(response.body().toString());
                    String code = jsonObject.getString("code");

                    if (code.equals("200")) {

                        showdialog();

                    } else {
                        startActivity(new Intent(PracticeTestActivity.this, QuestionsActivity.class).putExtra("series_id", test.getId()));

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });
    }

    private void showdialog() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(PracticeTestActivity.this);
        alertDialogBuilder.setMessage("Do you want to again attend this test ? ");

        alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();

                startActivity(new Intent(PracticeTestActivity.this, QuestionsActivity.class).putExtra("series_id", test.getId()));

            }
        });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();

    }
}
