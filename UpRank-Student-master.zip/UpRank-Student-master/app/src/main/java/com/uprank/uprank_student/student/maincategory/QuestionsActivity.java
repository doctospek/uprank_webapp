package com.uprank.uprank_student.student.maincategory;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.QuestionsAdapter;
import com.uprank.uprank_student.student.model.Question;
import com.uprank.uprank_student.student.model.QuestionsResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QuestionsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Question> arrayList;
    private ApiInterface apiInterface;
    private Student student;
    private Pref pref = new Pref();
    private String series_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        series_id = getIntent().getStringExtra("series_id");


        initView();
    }

    private void initView() {

        apiInterface = ApiClient.getClient(QuestionsActivity.this).create(ApiInterface.class);
        student = pref.getStudentDataPref(QuestionsActivity.this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), PracticeTestActivity.class));
            }
        });


        recyclerView = findViewById(R.id.questions_recyclerview);

        getQuestions();


    }

    private void getQuestions() {

        ProgressDialog progressDialog=new ProgressDialog(QuestionsActivity.this);
        progressDialog.setTitle("Loading");
        progressDialog.setCancelable(false);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        apiInterface.get_test_questions(Integer.parseInt(series_id)).enqueue(new Callback<QuestionsResponse>() {
            @Override
            public void onResponse(Call<QuestionsResponse> call, Response<QuestionsResponse> response) {

                if (response.body().getCode().equals("200")) {

                    progressDialog.dismiss();

                    arrayList = response.body().getQuestions();

                    QuestionsAdapter questionListAdapter = new QuestionsAdapter(QuestionsActivity.this, arrayList);
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setAdapter(questionListAdapter);
                } else {

                    progressDialog.dismiss();
                    CommonUtils.errorToast(QuestionsActivity.this, "No Questions Found");
                }
            }

            @Override
            public void onFailure(Call<QuestionsResponse> call, Throwable t) {

                progressDialog.dismiss();

                CommonUtils.errorToast(QuestionsActivity.this, "No Questions Found");
            }
        });
    }
}
