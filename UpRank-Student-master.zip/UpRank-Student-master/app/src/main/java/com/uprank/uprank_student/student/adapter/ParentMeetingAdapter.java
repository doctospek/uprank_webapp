package com.uprank.uprank_student.student.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Meeting;

import java.util.List;

public class ParentMeetingAdapter extends BaseAdapter {

    private Context context;
    private List<Meeting> meetingList;

    public ParentMeetingAdapter(Context context, List<Meeting> meetingList) {
        this.context = context;
        this.meetingList = meetingList;
    }

    @Override
    public int getCount() {
        return meetingList.size();
    }

    @Override
    public Object getItem(int position) {
        return meetingList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = layoutInflater.inflate(R.layout.meeting_view, parent, false);


        Meeting meeting = meetingList.get(position);


        TextView textView_message = convertView.findViewById(R.id.text_message);
        TextView textView_venue = convertView.findViewById(R.id.text_venue);
        TextView textView_date = convertView.findViewById(R.id.text_date_time);

        textView_date.setText("On " + meeting.getDate() + " At " + meeting.getTime());
        textView_venue.setText(meeting.getVenue());
        textView_message.setText(meeting.getMessage());

        return convertView;
    }
}
