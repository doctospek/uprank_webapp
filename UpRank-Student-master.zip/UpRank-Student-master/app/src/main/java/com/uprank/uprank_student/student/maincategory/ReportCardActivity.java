package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.DetailReportCardActivity;

import java.util.ArrayList;

public class ReportCardActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    private ListView listView;
    private ArrayList<String> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_card);

        initView();
    }

    private void initView() {

        listView = findViewById(R.id.listview_scorecard);
        listView.setOnItemClickListener(this);

        arrayList.add("Exam 1");
        arrayList.add("Exam 2");


        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(ReportCardActivity.this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        startActivity(new Intent(ReportCardActivity.this, DetailReportCardActivity.class));

    }
}
