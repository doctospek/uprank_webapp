package com.uprank.uprank_student.student.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.TestResultAdapter;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.model.TestResult;
import com.uprank.uprank_student.student.model.TestResultResponse;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class ReportcardFragment extends Fragment {

    private Student student;
    private List<TestResult> testResultList;
    private Pref pref = new Pref();
    private ApiInterface apiInterface;
    private ListView listView;

    public ReportcardFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_reportcard, container, false);


        initView(view);

        return view;
    }

    private void initView(View view) {
        apiInterface = ApiClient.getClient(getActivity()).create(ApiInterface.class);
        student = pref.getStudentDataPref(getActivity());

        listView = view.findViewById(R.id.listview_result);

        getResult();

    }

    private void getResult() {

        apiInterface.get_test_result(Integer.parseInt(student.getId())).enqueue(new Callback<TestResultResponse>() {
            @Override
            public void onResponse(Call<TestResultResponse> call, Response<TestResultResponse> response) {

                if (response.body().getCode().equals("200")) {

                    testResultList = response.body().getTestResult();
                    TestResultAdapter testResultAdapter = new TestResultAdapter(getActivity(), testResultList);
                    listView.setAdapter(testResultAdapter);

                } else {

                }
            }

            @Override
            public void onFailure(Call<TestResultResponse> call, Throwable t) {

            }
        });
    }
}
