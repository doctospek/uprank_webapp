package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.ExamScheduleTabLayoutAdapter;
import com.google.android.material.tabs.TabLayout;

public class ExamScheduleActivity extends AppCompatActivity {

    private static ViewPager tabPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exam_schedule);

        initView();
    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        //toolbar.inflateMenu(R.menu.main_menu);

        tabLayout = findViewById(R.id.tabs);
        tabPager = findViewById(R.id.pagerTab);

        tabLayout.addTab(tabLayout.newTab().setText("Upcoming Exams"));
        tabLayout.addTab(tabLayout.newTab().setText("Past Exams"));
        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#03DAC5"));
        tabLayout.setTabTextColors(Color.parseColor("#727272"), Color.parseColor("#03DAC5"));

        tabPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        ExamScheduleTabLayoutAdapter examScheduleTabLayoutAdapter = new ExamScheduleTabLayoutAdapter(getBaseContext(), getSupportFragmentManager(), tabLayout.getTabCount());
        tabPager.setAdapter(examScheduleTabLayoutAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tabPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }


}
