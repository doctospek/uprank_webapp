package com.uprank.uprank_student.student.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.LoginResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StudentProfile extends AppCompatActivity {

    Student student;
    Pref pref = new Pref();
    ApiInterface apiInterface;
    TextView textView_name, textView_batch, textView_roll_no, textView_guardian_name, textView_guardian_contat, textView_present_address,
            textView_permanent_address, textView_guardian_email, textView_student_course;
    CircleImageView image;
    private int GALLERY = 1, CAMERA = 2, STORAGE_PERMISSION_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);

        checkPermission(Manifest.permission.CAMERA, CAMERA);
        checkPermission(Manifest.permission.READ_EXTERNAL_STORAGE, STORAGE_PERMISSION_CODE);

        student = pref.getStudentDataPref(StudentProfile.this);
        apiInterface = ApiClient.getClient(StudentProfile.this).create(ApiInterface.class);

        initView();

    }

    private void initView() {
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        toolbar.inflateMenu(R.menu.student_profile_menu);

        textView_name = findViewById(R.id.text_student_name);
        textView_batch = findViewById(R.id.student_batch);
        textView_roll_no = findViewById(R.id.student_roll_no);
        textView_guardian_name = findViewById(R.id.student_guardians_name);
        textView_guardian_contat = findViewById(R.id.student_guardian_contact);
        textView_present_address = findViewById(R.id.student_present_address);
        textView_permanent_address = findViewById(R.id.student_permanent_address);
        textView_student_course = findViewById(R.id.student_course);
        textView_guardian_email = findViewById(R.id.student_guardian_email);
        image = findViewById(R.id.image_profile_pic);

        textView_name.setText(student.getFname() + " " + student.getMname() + " " + student.getLname());
        textView_batch.setText(student.getmBatchName());
        textView_roll_no.setText("Roll No : " + student.getId());
        textView_present_address.setText(student.getCurrentAddress());
        textView_permanent_address.setText(student.getPermanentAddress());
        textView_guardian_name.setText(student.getmGuardianName());
        textView_guardian_contat.setText(student.getGuardianMobile());
        textView_guardian_email.setText(student.getGuardianEmail());
        textView_student_course.setText(student.getmCourseName());
        Glide.with(StudentProfile.this).load("http://saiinfra.co.in/drline.saiinfra.co.in/uprank/app_api/student_api/uploads/" + student.getmProfilePic()).error(R.mipmap.ic_launcher).into(image);


        //getStudentInfo();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.student_profile_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menuWithIconText:

                startActivity(new Intent(StudentProfile.this, EditStudentProfileActivity.class));

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void getStudentInfo() {

        apiInterface.get_student_info(Integer.parseInt(student.getId())).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                if (response.body().getCode().equals("200")) {


                    Student student = response.body().getStudent().get(0);
                    textView_name.setText(student.getFname() + " " + student.getMname() + " " + student.getLname());
                    textView_batch.setText(student.getmBatchName());
                    textView_roll_no.setText("Roll No : " + student.getId());
                    textView_present_address.setText(student.getCurrentAddress());
                    textView_permanent_address.setText(student.getPermanentAddress());
                    textView_guardian_name.setText(student.getmGuardianName());
                    textView_guardian_contat.setText(student.getGuardianMobile());
                    textView_guardian_email.setText(student.getGuardianEmail());
                    textView_student_course.setText(student.getmCourseName());

                    Picasso.with(StudentProfile.this).load("http://saiinfra.co.in/drline.saiinfra.co.in/uprank/app_api/student_api/uploads/" + student.getmProfilePic()).error(R.mipmap.ic_launcher).into(image);

                    pref.setStudentDataPref(StudentProfile.this, student);

                } else {


                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {

            }
        });

    }

    public void checkPermission(String permission, int requestCode) {
        if (ContextCompat.checkSelfPermission(StudentProfile.this, permission)
                == PackageManager.PERMISSION_DENIED) {


            ActivityCompat.requestPermissions(StudentProfile.this,
                    new String[]{permission},
                    requestCode);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == CAMERA) {

            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(StudentProfile.this,
                        "Camera Permission Granted",
                        Toast.LENGTH_SHORT)
                        .show();
            } else {
                Toast.makeText(StudentProfile.this,
                        "CAMERA Permission Denied",
                        Toast.LENGTH_SHORT)
                        .show();
            }
        }

    }
    
}
