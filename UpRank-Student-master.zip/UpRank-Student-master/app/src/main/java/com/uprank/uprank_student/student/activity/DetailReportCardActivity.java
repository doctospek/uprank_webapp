package com.uprank.uprank_student.student.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.tabs.TabLayout;
import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.adapter.ExamScheduleTabLayoutAdapter;
import com.uprank.uprank_student.student.adapter.ReportCardTabLayoutAdapter;

public class DetailReportCardActivity extends AppCompatActivity {

    private static ViewPager tabPager;
    TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_report_card);

        initView();
    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });


        tabLayout = findViewById(R.id.tabs);
        tabPager = findViewById(R.id.pagerTab);

        tabLayout.addTab(tabLayout.newTab().setText("Score Card"));
        //tabLayout.addTab(tabLayout.newTab().setText("Progress"));

        tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#03DAC5"));
        tabLayout.setTabTextColors(Color.parseColor("#727272"), Color.parseColor("#03DAC5"));

        tabPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        ReportCardTabLayoutAdapter reportCardTabLayoutAdapter = new ReportCardTabLayoutAdapter(getBaseContext(), getSupportFragmentManager(), tabLayout.getTabCount());
        tabPager.setAdapter(reportCardTabLayoutAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                tabPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}
