package com.uprank.uprank_student.student.maincategory;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.StudentDashboard;
import com.uprank.uprank_student.student.adapter.NotesAdapter;
import com.uprank.uprank_student.student.model.Note;
import com.uprank.uprank_student.student.model.NotesResponse;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.CommonUtils;
import com.uprank.uprank_student.student.utility.Pref;
import com.uprank.uprank_student.student.webservices.ApiClient;
import com.uprank.uprank_student.student.webservices.ApiInterface;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotesActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ApiInterface apiInterface;
    private Student student;
    private Pref pref = new Pref();
    private NotesAdapter notesAdapter;
    private List<Note> noteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        apiInterface = ApiClient.getClient(NotesActivity.this).create(ApiInterface.class);
        student = pref.getStudentDataPref(NotesActivity.this);

        initView();


    }

    private void initView() {

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(getBaseContext(), StudentDashboard.class));
            }
        });

        //toolbar.inflateMenu(R.menu.main_menu);

        recyclerView = findViewById(R.id.recyclerview_notes);

        getNotes();
    }


    private void getNotes() {

        apiInterface.get_notes(Integer.parseInt(student.getInstituteId()), student.getCourse(), student.getBatch()).enqueue(new Callback<NotesResponse>() {
            @Override
            public void onResponse(Call<NotesResponse> call, Response<NotesResponse> response) {

                if (response.body().getCode().equals("200")) {

                    noteList = response.body().getNotes();

                    notesAdapter = new NotesAdapter(NotesActivity.this, noteList);
                    recyclerView.setHasFixedSize(true);
                    recyclerView.setAdapter(notesAdapter);

                } else {
                    CommonUtils.errorToast(NotesActivity.this, response.body().getMsg());
                }

            }

            @Override
            public void onFailure(Call<NotesResponse> call, Throwable t) {

            }
        });

    }


}
