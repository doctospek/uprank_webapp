package com.uprank.uprank_student.student.utilities;

import android.graphics.Color;

public class Colors {

    public static final int[] MATERIAL_COLORS = {
            rgb("#0288D1"), rgb("#03DAC5")
    };

    public static int rgb(String hex) {
        int color = (int) Long.parseLong(hex.replace("#", ""), 16);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = (color >> 0) & 0xFF;
        return Color.rgb(r, g, b);
    }

}
