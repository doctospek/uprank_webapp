package com.uprank.uprank_student.student.utility;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
