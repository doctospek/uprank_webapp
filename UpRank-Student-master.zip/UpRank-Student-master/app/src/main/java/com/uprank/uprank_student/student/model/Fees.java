
package com.uprank.uprank_student.student.model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Fees {

    @SerializedName("amount")
    private String mAmount;
    @SerializedName("batch")
    private String mBatch;
    @SerializedName("course")
    private String mCourse;
    @SerializedName("due_date")
    private String mDueDate;
    @SerializedName("id")
    private String mId;
    @SerializedName("installnemt_count")
    private String mInstallnemtCount;
    @SerializedName("institute_id")
    private String mInstituteId;
    @SerializedName("total_fees")
    private String mTotalFees;

    public String getAmount() {
        return mAmount;
    }

    public void setAmount(String amount) {
        mAmount = amount;
    }

    public String getBatch() {
        return mBatch;
    }

    public void setBatch(String batch) {
        mBatch = batch;
    }

    public String getCourse() {
        return mCourse;
    }

    public void setCourse(String course) {
        mCourse = course;
    }

    public String getDueDate() {
        return mDueDate;
    }

    public void setDueDate(String dueDate) {
        mDueDate = dueDate;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstallnemtCount() {
        return mInstallnemtCount;
    }

    public void setInstallnemtCount(String installnemtCount) {
        mInstallnemtCount = installnemtCount;
    }

    public String getInstituteId() {
        return mInstituteId;
    }

    public void setInstituteId(String instituteId) {
        mInstituteId = instituteId;
    }

    public String getTotalFees() {
        return mTotalFees;
    }

    public void setTotalFees(String totalFees) {
        mTotalFees = totalFees;
    }

}
