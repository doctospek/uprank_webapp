package com.uprank.uprank_student.student.adapter;

import android.app.Activity;
import android.os.Handler;

import androidx.viewpager.widget.ViewPager;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.model.Slider;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;


public class ViewPagerAdapter {

    private ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    private int[] IMAGES;
    private ArrayList<String> ImagesArray;
    private Activity activity;
    //    ArrayList<String> arrayListImages = new ArrayList<>();
    private ArrayList<Slider> arrayListSlider=new ArrayList<>();
    private ImageAdapter imageAdapter;


    public ViewPagerAdapter(Activity mContext, ViewPager view) {
        this.activity = mContext;
        this.mPager = view;
        getImages();

    }

    public void ScrollPager() {


        CirclePageIndicator indicator = this.activity.findViewById(R.id.indicator);
        indicator.setViewPager(mPager);
        final float density = this.activity.getResources().getDisplayMetrics().density;
        indicator.setRadius(5 * density);


        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);

            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 3000, 3000);

        //Pager listener over indicator
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;
            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {


            }

            @Override
            public void onPageScrollStateChanged(int pos) {
            }
        });


    }


    private void getImages() {

        IMAGES = new int[4];

        Slider slider = new Slider();
        slider.setImg(R.drawable.banner);
        IMAGES[0]=slider.getImg();

        Slider slider1 = new Slider();
        slider1.setImg(R.drawable.banner);
        IMAGES[1]=slider1.getImg();

        Slider slider2 = new Slider();
        slider2.setImg(R.drawable.banner);
        IMAGES[2]=slider2.getImg();

        Slider slider3 = new Slider();
        slider3.setImg(R.drawable.banner);
        IMAGES[3]=slider3.getImg();

        NUM_PAGES = IMAGES.length;

        arrayListSlider.add(slider);
        arrayListSlider.add(slider1);
        arrayListSlider.add(slider2);
        arrayListSlider.add(slider3);

        imageAdapter = new ImageAdapter(activity, arrayListSlider);
        mPager.setAdapter(imageAdapter);

    }
}
