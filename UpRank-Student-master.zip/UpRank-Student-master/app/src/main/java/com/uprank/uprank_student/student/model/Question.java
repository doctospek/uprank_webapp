
package com.uprank.uprank_student.student.model;

import javax.annotation.Generated;
import com.google.gson.annotations.SerializedName;

@Generated("net.hexar.json2pojo")
@SuppressWarnings("unused")
public class Question {

    @SerializedName("ans1")
    private String mAns1;
    @SerializedName("ans2")
    private String mAns2;
    @SerializedName("ans3")
    private String mAns3;
    @SerializedName("ans4")
    private String mAns4;
    @SerializedName("batch")
    private String mBatch;
    @SerializedName("batch_name")
    private Object mBatchName;
    @SerializedName("course")
    private String mCourse;
    @SerializedName("course_name")
    private Object mCourseName;
    @SerializedName("id")
    private String mId;
    @SerializedName("institute_id")
    private String mInstituteId;
    @SerializedName("publish")
    private String mPublish;
    @SerializedName("question")
    private String mQuestion;
    @SerializedName("result")
    private String mResult;
    @SerializedName("serise_id")
    private String mSeriseId;

    public String getAns1() {
        return mAns1;
    }

    public void setAns1(String ans1) {
        mAns1 = ans1;
    }

    public String getAns2() {
        return mAns2;
    }

    public void setAns2(String ans2) {
        mAns2 = ans2;
    }

    public String getAns3() {
        return mAns3;
    }

    public void setAns3(String ans3) {
        mAns3 = ans3;
    }

    public String getAns4() {
        return mAns4;
    }

    public void setAns4(String ans4) {
        mAns4 = ans4;
    }

    public String getBatch() {
        return mBatch;
    }

    public void setBatch(String batch) {
        mBatch = batch;
    }

    public Object getBatchName() {
        return mBatchName;
    }

    public void setBatchName(Object batchName) {
        mBatchName = batchName;
    }

    public String getCourse() {
        return mCourse;
    }

    public void setCourse(String course) {
        mCourse = course;
    }

    public Object getCourseName() {
        return mCourseName;
    }

    public void setCourseName(Object courseName) {
        mCourseName = courseName;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }

    public String getInstituteId() {
        return mInstituteId;
    }

    public void setInstituteId(String instituteId) {
        mInstituteId = instituteId;
    }

    public String getPublish() {
        return mPublish;
    }

    public void setPublish(String publish) {
        mPublish = publish;
    }

    public String getQuestion() {
        return mQuestion;
    }

    public void setQuestion(String question) {
        mQuestion = question;
    }

    public String getResult() {
        return mResult;
    }

    public void setResult(String result) {
        mResult = result;
    }

    public String getSeriseId() {
        return mSeriseId;
    }

    public void setSeriseId(String seriseId) {
        mSeriseId = seriseId;
    }

}
