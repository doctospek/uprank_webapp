package com.uprank.uprank_student.student.activity.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.uprank.uprank_student.R;
import com.uprank.uprank_student.student.activity.DetailReportCardActivity;
import com.uprank.uprank_student.student.adapter.HomeAdapter;
import com.uprank.uprank_student.student.maincategory.ExamScheduleActivity;
import com.uprank.uprank_student.student.maincategory.FeesActivity;
import com.uprank.uprank_student.student.maincategory.HomeWorkActivity;
import com.uprank.uprank_student.student.maincategory.MyAttendanceActivity;
import com.uprank.uprank_student.student.maincategory.NotesActivity;
import com.uprank.uprank_student.student.maincategory.NoticeBoardActivity;
import com.uprank.uprank_student.student.maincategory.ParentMeetingActivity;
import com.uprank.uprank_student.student.maincategory.PracticeTestActivity;
import com.uprank.uprank_student.student.maincategory.ReportCardActivity;
import com.uprank.uprank_student.student.maincategory.TimeTableActivity;
import com.uprank.uprank_student.student.maincategory.TutorActivity;
import com.uprank.uprank_student.student.model.MainCategory;
import com.uprank.uprank_student.student.model.Student;
import com.uprank.uprank_student.student.utility.Pref;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class HomeFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemClickListener {

    private GridView gridView;
    private Pref pref = new Pref();
    private Student student;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);

        student = pref.getStudentDataPref(getActivity());

        initView(root);
        setCategoryList();

        return root;
    }

    private void initView(View view) {

        gridView = view.findViewById(R.id.gridview_category);
        TextView textView = view.findViewById(R.id.text_greeting);
        TextView textView_name= view.findViewById(R.id.text_name);
        gridView.setOnItemClickListener(this);

        Date date = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int hour = cal.get(Calendar.HOUR_OF_DAY);

        String greeting;
        if (hour >= 12 && hour < 17) {
            greeting = "Good Afternoon";
        } else if (hour >= 17 && hour < 21) {
            greeting = "Good Evening";
        } else if (hour >= 21 && hour < 24) {
            greeting = "Good Night";
        } else {
            greeting = "Good Morning";
        }

        textView.setText(greeting);
        textView_name.setText(student.getFname());
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        switch (position) {

            case 0:
                startActivity(new Intent(getActivity(), MyAttendanceActivity.class));
                break;

            case 1:
                startActivity(new Intent(getActivity(), TimeTableActivity.class));
                break;

            case 2:
                startActivity(new Intent(getActivity(), HomeWorkActivity.class));
                break;

            case 3:
                startActivity(new Intent(getActivity(), NoticeBoardActivity.class));
                break;

            case 4:
                startActivity(new Intent(getActivity(), NotesActivity.class));
                break;

            case 5:
                startActivity(new Intent(getActivity(), ExamScheduleActivity.class));
                break;

            case 6:
                startActivity(new Intent(getActivity(), FeesActivity.class));
                break;

            case 7:

                startActivity(new Intent(getActivity(), DetailReportCardActivity.class));

                break;

            case 8:
                startActivity(new Intent(getActivity(), ParentMeetingActivity.class));
                break;

            case 9:
                break;

            case 10:

                startActivity(new Intent(getActivity(), PracticeTestActivity.class));
                break;

            case 12:
                startActivity(new Intent(getActivity(), TutorActivity.class));
                break;


        }
    }

    private void setCategoryList() {

        ArrayList<MainCategory> arrayList = new ArrayList<>();

        arrayList.add(new MainCategory(1, "My\nAttendance", R.mipmap.attendance));
        arrayList.add(new MainCategory(2, "Timetable", R.mipmap.schooltimetable));
        arrayList.add(new MainCategory(3, "Homework", R.mipmap.homework));
        arrayList.add(new MainCategory(4, "Notice Board", R.mipmap.noticeboard));
        arrayList.add(new MainCategory(5, "Notes / Study Material", R.mipmap.notes));
        arrayList.add(new MainCategory(6, "Exam Schedule", R.mipmap.examschedule));
        arrayList.add(new MainCategory(7, "Fees Details", R.mipmap.fees));
        arrayList.add(new MainCategory(8, "Score Card", R.mipmap.scorecard));
        arrayList.add(new MainCategory(9, "Parent \nMeeting", R.mipmap.meeting));
        arrayList.add(new MainCategory(10, "Gallery", R.mipmap.gallery));
        arrayList.add(new MainCategory(11, "Practice Test", R.mipmap.practicetest));
        arrayList.add(new MainCategory(12, "Go Live", R.mipmap.golive));
        arrayList.add(new MainCategory(13, "Tutor", R.mipmap.tutor));

        HomeAdapter homeAdapter = new HomeAdapter(getActivity(), arrayList);
        gridView.setAdapter(homeAdapter);

    }
}
