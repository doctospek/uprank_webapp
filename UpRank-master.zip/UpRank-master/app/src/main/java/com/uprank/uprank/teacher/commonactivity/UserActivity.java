package com.uprank.uprank.teacher.commonactivity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.uprank.uprank.R;

public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
    }
}
