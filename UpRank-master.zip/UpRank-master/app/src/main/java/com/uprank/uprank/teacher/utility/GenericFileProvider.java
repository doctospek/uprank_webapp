package com.uprank.uprank.teacher.utility;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
